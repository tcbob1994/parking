ESX = nil

local PlayerLoaded = false
local SetupComplete = false
local parked = false
local engine = false
local gps = false
local locked = false

local lockpicked = false
local canLockpick = false
local isLockpicking = false
local vehLocked = false

local hotwired = false
local canHotwire = false
local isHotwireing = false

local searchPosition = nil
local searchPlate = nil
local searchVehicle = false

local canInstallGPS = false
local canUninstallGPS = false
local isInstalling = false
local vehicleGPS = false
local vehicleNoGPS = false

local vehicles = {}; RPWorking = true
local wasInVehicle = false
local isParked = false
local isOwned = false

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(100)
	end
	ESX.PlayerData = ESX.GetPlayerData()
	PlayerLoaded = true
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(100)
		if PlayerLoaded then
			if Config.Locale == 'de' or Config.Locale == 'en' or Config.Locale == 'rus' or Config.Locale == 'fr' or Config.Locale == 'es' then
			else
				ESX.ShowNotification('~r~PARKING:~r~ ~w~Config.Locale not Found! ~w~')
			end
			if Config.Garages and Config.AdvancedGarage then
				ESX.ShowNotification(_U('config_code2'))
			end
			if Config.EnableLockpick and Config.key1 == nil then
				ESX.ShowNotification(_U('config_code3'))
			end
			if Config.EnableHotwire and Config.key2 == nil then
				ESX.ShowNotification(_U('config_code4'))
			end
			if Config.EnableToggleEngine and Config.key3 == nil then
				ESX.ShowNotification(_U('config_code5'))
			end
			if Config.EnableLockCar and Config.key4 == nil then
				ESX.ShowNotification(_U('config_code6'))
			end
			if Config.EnableLockpick and not Config.EnablePolice and not Config.EnableMechanic and not Config.EnableCiv then
				ESX.ShowNotification(_U('config_code7'))
			end
			if Config.EnableHotwire and not Config.EnablePolice and not Config.EnableMechanic and not Config.EnableCiv then
				ESX.ShowNotification(_U('config_code16'))
			end
			if Config.PoliceJobName == nil and EnablePolice then
				ESX.ShowNotification(_U('config_code8'))
			end
			if Config.MechanicJobName == nil and EnableMechanic then
				ESX.ShowNotification(_U('config_code9'))
			end
			if Config.EnableLockpick and Config.EnablePolice and Config.LockPickItemPoliceNeeded and Config.LockPickItemPolice == nil then
				ESX.ShowNotification(_U('config_code10'))
			end
			if Config.EnableLockpick and Config.EnableMechanic and Config.LockPickItemMechanicNeeded and Config.LockPickItemMechanic == nil then
				ESX.ShowNotification(_U('config_code11'))
			end
			if Config.EnableLockpick and Config.EnableCiv and Config.LockPickItemCivNeeded and Config.LockPickItemCiv == nil then
				ESX.ShowNotification(_U('config_code12'))
			end
			if Config.EnableHotwire and Config.EnablePolice and Config.HotwireItemPoliceNeeded and Config.HotwireItemPolice == nil then
				ESX.ShowNotification(_U('config_code13'))
			end
			if Config.EnableHotwire and Config.EnableMechanic and Config.HotwireItemMechanicNeeded and Config.HotwireItemMechanic == nil then
				ESX.ShowNotification(_U('config_code14'))
			end
			if Config.EnableHotwire and Config.EnableCiv and Config.HotwireItemCivNeeded and Config.HotwireItemCiv == nil then
				ESX.ShowNotification(_U('config_code15'))
			end
		end
	end
end)

Citizen.CreateThread(function()
	while not SetupComplete do
		Citizen.Wait(100)
		if PlayerLoaded then
			ESX.TriggerServerCallback('parking:CheckNewVersion', function(isNewestVersion)
				if isNewestVersion then
					SetupComplete = true
				else
					SetupComplete = false
					ESX.ShowNotification(_U('need_setup'))
				end
			end)
			if Config.EnableSlowMode then
				Wait( Config.SlowModeTime*1000 )
				if SetupComplete then
					TriggerServerEvent("parking:StartParking")
				end
			else
				if SetupComplete then
					TriggerServerEvent("parking:StartParking")
				end
			end
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(100)
		if PlayerLoaded then
			local ped = PlayerPedId()
			local isInVehicle = IsPedInAnyVehicle(ped)
			if isInVehicle then
				ESX.TriggerServerCallback('parking:CheckIfVehicleOwned', function(owned)
					local veh = GetVehiclePedIsIn(ped, true)
					local vehProps = ESX.Game.GetVehicleProperties(veh)
					local plate = vehProps.plate
					local vehPos = GetEntityCoords(veh)
					local headings = GetEntityHeading(veh)
					local engine = GetIsVehicleEngineRunning(veh)
					local coords = {
						x = vehPos.x,
						y = vehPos.y,
						z = vehPos.z, 
						heading = headings
					}
					local locked = false
					if GetVehicleDoorLockStatus(veh) == 1 then
						locked = false
					else
						locked = true
					end
					local engine = GetIsVehicleEngineRunning(veh)
					hotwired = hotwired
					local parked = true
					if not gps then
						ESX.TriggerServerCallback('parking:CheckVehicleGPS', function(getgps)
							if getgps then
								gps = true
							else
								gps = false
							end
						end,plate)
					end
					if owned then
						if engine then
							local seat1 = GetPedInVehicleSeat(veh, -1)
							if PlayerPedId() == seat1 then
								TriggerServerEvent('parking:ParkVehicle', plate, vehProps, coords, locked, hotwired, parked, engine, gps )
							end
						end
					else
						if engine then
							local seat1 = GetPedInVehicleSeat(veh, -1)
							if PlayerPedId() == seat1 then
								if Config.UseNPCcars then
									TriggerServerEvent('parking:ParkVehicle', plate, vehProps, coords, locked, hotwired, parked, engine, gps )
								end
							end
						end
					end
				end, plate)
			end
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
		if isHotwireing or isLockpicking or isInstalling then
			DisableControlAction(0, 24, true)
			DisableControlAction(0, 257, true)
			DisableControlAction(0, 25, true)
			DisableControlAction(0, 263, true)
			DisableControlAction(0, 32, true)
			DisableControlAction(0, 34, true)
			DisableControlAction(0, 31, true)
			DisableControlAction(0, 30, true)

			DisableControlAction(0, 45, true)
			DisableControlAction(0, 22, true)
			DisableControlAction(0, 44, true)
			DisableControlAction(0, 37, true)
			DisableControlAction(0, 23, true)

			DisableControlAction(0, 288, true)
			DisableControlAction(0, 289, true)
			DisableControlAction(0, 170, true)
			DisableControlAction(0, 167, true)
			DisableControlAction(0, 26, true)
			DisableControlAction(0, 73, true)
			DisableControlAction(2, 199, true)

			DisableControlAction(0, 59, true)
			DisableControlAction(0, 71, true)
			DisableControlAction(0, 72, true)

			DisableControlAction(2, 36, true)

			DisableControlAction(0, 47, true)
			DisableControlAction(0, 264, true)
			DisableControlAction(0, 257, true)
			DisableControlAction(0, 140, true)
			DisableControlAction(0, 141, true)
			DisableControlAction(0, 142, true)
			DisableControlAction(0, 143, true)
			DisableControlAction(0, 75, true)
			DisableControlAction(27, 75, true)
		end
	end
end)

Citizen.CreateThread(function()
    while true do
		Citizen.Wait(0)
		if PlayerLoaded then
			local ped = PlayerPedId()
			local veh = GetVehiclePedIsIn(ped)
			local lock = GetVehicleDoorLockStatus(veh)
			local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
			local isHotwired = GetIsVehicleEngineRunning(veh)
			local isEnteringVehicle = false
			local isInVehicle = IsPedInAnyVehicle(ped)
			local ppos = GetEntityCoords(ped)
			local veh = GetClosestVehicle(ppos, 1.5, 0, 70)
			local vpos = GetEntityCoords(veh)
			local distance = GetDistanceBetweenCoords(ppos, vpos, false)
			Wait(10)
			if not isInVehicle and Config.EnableLockpick and distance <= 1.5 and not isLockpicking then
				Wait(10)
				if Config.UseNPCcars then
					ESX.TriggerServerCallback('parking:CheckIfVehicleOwned', function(owned)
						if not owned then
							ESX.TriggerServerCallback('parking:isVehicleOwner', function(owner)
								if not owner then
									ESX.TriggerServerCallback('parking:CheckVehicleLocked', function(locked)
										if not locked then
											ESX.TriggerServerCallback('parking:CheckVehicleLockpicked', function(lockpicked)
												if not lockpicked then
													ESX.ShowHelpNotification(_U('push_lockpicking'));
													canLockpick = true
												end
											end, plate)
										end
									end, plate)
								else
									canLockpick = false
								end
							end)
						end
					end, plate)
				else
					ESX.TriggerServerCallback('parking:isVehicleOwner', function(owner)
						if not owner then
							ESX.TriggerServerCallback('parking:CheckVehicleLocked', function(locked)
								if not locked then
									ESX.TriggerServerCallback('parking:CheckVehicleLockpicked', function(lockpicked)
										if not lockpicked then
											ESX.ShowHelpNotification(_U('push_lockpicking'));
											canLockpick = true
										end
									end, plate)
								end
							end, plate)
						else
							canLockpick = false
						end
					end)
				end
			elseif not isInVehicle and distance >= 1.5 then 
				canLockpick = false
			end
			if isInVehicle and Config.EnableHotwire and canHotwire then
				Wait(10)
				if Config.UseNPCcars then
					ESX.TriggerServerCallback('parking:CheckIfVehicleOwned', function(owned)
						if not owned then
							ESX.TriggerServerCallback('parking:CheckVehicleHotwired', function(hotwired)
								if not hotwired and canHotwire then
									ESX.ShowHelpNotification(_U('push_hotwireing'));
									canHotwire = true
								end
							end, plate)
						end
					end, plate)
				else
					ESX.TriggerServerCallback('parking:CheckVehicleHotwired', function(hotwired)
						if not hotwired and canHotwire then
							ESX.ShowHelpNotification(_U('push_hotwireing'));
							canHotwire = true
						end
					end, plate)
				end
			end
			if not Config.UseNPCcars then
				ESX.TriggerServerCallback('parking:CheckIfVehicleOwned', function(owned)
					if owned then
						if not isInVehicle and IsControlJustPressed(0, Config.key1) and canLockpick and Config.EnableLockpick then
							
							isLockpicking = true
							canLockpick = false
							if Config.EnablePolice and ESX.PlayerData.job and ESX.PlayerData.job.name == Config.PoliceJobName then
								if Config.LockPickItemPoliceNeeded then
									ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
										if quantity > 0 then
											RequestAnimDict('anim@amb@clubhouse@tutorial@bkr_tut_ig3@')
											while not HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') do
												Citizen.Wait(0)
											end
											ESX.Streaming.RequestAnimDict("anim@amb@clubhouse@tutorial@bkr_tut_ig3@",function()
												TaskPlayAnim(GetPlayerPed(-1), 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@' , 'machinic_loop_mechandplayer' ,8.0, -8.0, -1, 1, 0, false, false, false )
											end)
											if Config.CanFailPolice then
												local fail = false
												local chance = Config.CanFailChancePolice
												local percent = math.random(100)
												local lock = GetVehicleDoorLockStatus(veh)
												local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
												if percent <= chance then
													exports['progressBars']:startUI(Config.LockpickPoliceTime*1000, _U('car_lockpicking'))
													Wait(Config.LockpickPoliceTime*1000)
													ClearPedTasksImmediately(ped)
													ClearPedTasks(ped)
													SetVehicleAlarm(veh, true)
													SetVehicleAlarmTimeLeft(veh, 30 * 1000)
													SetVehicleDoorsLocked(veh, 2)
													SetVehicleDoorsLockedForAllPlayers(veh, true)
													Wait(10)
													ClearPedTasksImmediately(ped) ClearPedTasks(ped)
													isEnteringVehicle = false
													ESX.ShowNotification(_U('car_failed'))
													TriggerServerEvent('parking:removeItem', Config.LockPickItemPolice)
													canLockpick = true
													isLockpicking = false
												else
													exports['progressBars']:startUI(Config.LockpickPoliceTime*1000, _U('car_lockpicking'))
													Wait(Config.LockpickPoliceTime*1000)
													ClearPedTasksImmediately(ped)
													SetVehicleDoorsLocked(veh, 1)
													SetVehicleDoorsLockedForAllPlayers(veh, false)
													Wait(10)
													isEnteringVehicle = false
													ESX.ShowNotification(_U('car_unlocked'))
													canHotwire = true
													isLockpicking = false
												end
											else
												exports['progressBars']:startUI(Config.LockpickPoliceTime*1000, _U('car_lockpicking'))
												Wait(Config.LockpickPoliceTime*1000)
												ClearPedTasksImmediately(ped) ClearPedTasks(ped)
												SetVehicleDoorsLocked(veh, 1)
												SetVehicleDoorsLockedForAllPlayers(veh, false)
												Wait(10)
												isEnteringVehicle = false
												ESX.ShowNotification(_U('car_unlocked'))
												canHotwire = true
												isLockpicking = false
											end
										else
											isLockpicking = false
											ESX.ShowNotification(_U('no_item'))
										end
									end, Config.LockPickItemPolice)
								else
									exports['progressBars']:startUI(Config.LockpickPoliceTime*1000, _U('car_lockpicking'))
									Wait(Config.LockpickPoliceTime*1000)
									ClearPedTasksImmediately(ped) ClearPedTasks(ped)
									SetVehicleDoorsLocked(veh, 1)
									SetVehicleDoorsLockedForAllPlayers(veh, false)
									Wait(10)
									isEnteringVehicle = false
									ESX.ShowNotification(_U('car_unlocked'))
									canHotwire = true
									isLockpicking = false
								end
							elseif Config.EnableMechanic and ESX.PlayerData.job and ESX.PlayerData.job.name == Config.MechanicJobName then
								if Config.LockPickItemMechanicNeeded then
									ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
										if quantity > 0 then
											RequestAnimDict('anim@amb@clubhouse@tutorial@bkr_tut_ig3@')
											while not HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') do
												Citizen.Wait(0)
											end
											ESX.Streaming.RequestAnimDict("anim@amb@clubhouse@tutorial@bkr_tut_ig3@",function()
												TaskPlayAnim(GetPlayerPed(-1), 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@' , 'machinic_loop_mechandplayer' ,8.0, -8.0, -1, 1, 0, false, false, false )
											end)
											if Config.CanFailMechanic then
												local fail = false
												local chance = Config.CanFailChanceMechanic
												local percent = math.random(100)
												local lock = GetVehicleDoorLockStatus(veh)
												local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
												if percent <= chance then
													exports['progressBars']:startUI(Config.LockpickMechanicTime*1000, _U('car_lockpicking'))
													Wait(Config.LockpickMechanicTime*1000)
													ClearPedTasksImmediately(ped)
													ClearPedTasks(ped)
													SetVehicleAlarm(veh, true)
													SetVehicleAlarmTimeLeft(veh, 30 * 1000)
													SetVehicleDoorsLocked(veh, 2)
													SetVehicleDoorsLockedForAllPlayers(veh, true)
													Wait(10)
													ClearPedTasksImmediately(ped) ClearPedTasks(ped)
													isEnteringVehicle = false
													ESX.ShowNotification(_U('car_failed'))
													TriggerServerEvent('parking:removeItem', Config.LockPickItemMechanic)
													isLockpicking = false
													canLockpick = true
												else
													exports['progressBars']:startUI(Config.LockpickMechanicTime*1000, _U('car_lockpicking'))
													Wait(Config.LockpickMechanicTime*1000)
													ClearPedTasksImmediately(ped)
													SetVehicleDoorsLocked(veh, 1)
													SetVehicleDoorsLockedForAllPlayers(veh, false)
													Wait(10)
													isEnteringVehicle = false
													ESX.ShowNotification(_U('car_unlocked'))
													isLockpicking = false
													canHotwire = true
												end
											else
												exports['progressBars']:startUI(Config.LockpickMechanicTime*1000, _U('car_lockpicking'))
												Wait(Config.LockpickMechanicTime*1000)
												ClearPedTasksImmediately(ped) ClearPedTasks(ped)
												SetVehicleDoorsLocked(veh, 1)
												SetVehicleDoorsLockedForAllPlayers(veh, false)
												Wait(10)
												isEnteringVehicle = false
												ESX.ShowNotification(_U('car_unlocked'))
												isLockpicking = false
												canHotwire = true
											end
										else
											isLockpicking = false
											ESX.ShowNotification(_U('no_item'))
										end
									end, Config.LockPickItemMechanic)
								else
									exports['progressBars']:startUI(Config.LockpickMechanicTime*1000, _U('car_lockpicking'))
									Wait(Config.LockpickMechanicTime*1000)
									ClearPedTasksImmediately(ped) ClearPedTasks(ped)
									SetVehicleDoorsLocked(veh, 1)
									SetVehicleDoorsLockedForAllPlayers(veh, false)
									Wait(10)
									isEnteringVehicle = false
									ESX.ShowNotification(_U('car_unlocked'))
									isLockpicking = false
									canHotwire = true
								end
							elseif Config.EnableCiv and not (ESX.PlayerData.job.name == Config.MechanicJobName) and not (ESX.PlayerData.job.name == Config.PoliceJobName) then
								if Config.LockPickItemCivNeeded then
									ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
										if quantity > 0 then
											RequestAnimDict('anim@amb@clubhouse@tutorial@bkr_tut_ig3@')
											while not HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') do
												Citizen.Wait(0)
											end
											ESX.Streaming.RequestAnimDict("anim@amb@clubhouse@tutorial@bkr_tut_ig3@",function()
												TaskPlayAnim(GetPlayerPed(-1), 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@' , 'machinic_loop_mechandplayer' ,8.0, -8.0, -1, 1, 0, false, false, false )
											end)
											if Config.CanFailCiv then
												local fail = false
												local chance = Config.CanFailChanceCiv
												local percent = math.random(100)
												local lock = GetVehicleDoorLockStatus(veh)
												local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
												if percent <= chance then
													exports['progressBars']:startUI(Config.LockpickCivTime*1000, _U('car_lockpicking'))
													Wait(Config.LockpickCivTime*1000)
													ClearPedTasksImmediately(ped)
													ClearPedTasks(ped)
													SetVehicleAlarm(veh, true)
													SetVehicleAlarmTimeLeft(veh, 30 * 1000)
													SetVehicleDoorsLocked(veh, 2)
													SetVehicleDoorsLockedForAllPlayers(veh, true)
													Wait(10)
													ClearPedTasksImmediately(ped) ClearPedTasks(ped)
													isEnteringVehicle = false
													ESX.ShowNotification(_U('car_failed'))
													TriggerServerEvent('parking:removeItem', Config.LockPickItemCiv)
													isLockpicking = false
													canLockpick = true
												else
													exports['progressBars']:startUI(Config.LockpickCivTime*1000, _U('car_lockpicking'))
													Wait(Config.LockpickCivTime*1000)
													ClearPedTasksImmediately(ped)
													SetVehicleDoorsLocked(veh, 1)
													SetVehicleDoorsLockedForAllPlayers(veh, false)
													Wait(10)
													isEnteringVehicle = false
													ESX.ShowNotification(_U('car_unlocked'))
													isLockpicking = false
													canHotwire = true
												end
											else
												exports['progressBars']:startUI(Config.LockpickCivTime*1000, _U('car_lockpicking'))
												Wait(Config.LockpickCivTime*1000)
												ClearPedTasksImmediately(ped) ClearPedTasks(ped)
												SetVehicleDoorsLocked(veh, 1)
												SetVehicleDoorsLockedForAllPlayers(veh, false)
												Wait(10)
												isEnteringVehicle = false
												ESX.ShowNotification(_U('car_unlocked'))
												isLockpicking = false
												canHotwire = true
											end
										else
											isLockpicking = false
											ESX.ShowNotification(_U('no_item'))
										end
									end, Config.LockPickItemCiv)
								else
									exports['progressBars']:startUI(Config.LockpickCivTime*1000, _U('car_lockpicking'))
									Wait(Config.LockpickCivTime*1000)
									ClearPedTasksImmediately(ped) ClearPedTasks(ped)
									SetVehicleDoorsLocked(veh, 1)
									SetVehicleDoorsLockedForAllPlayers(veh, false)
									Wait(10)
									isEnteringVehicle = false
									ESX.ShowNotification(_U('car_unlocked'))
									isLockpicking = false
									canHotwire = true
								end
							end
						end
						if isInVehicle and IsControlJustPressed(0, Config.key2) and canHotwire and Config.EnableHotwire and isInVehicle then
							
							canHotwire = false
							isHotwireing = true
							if Config.EnablePolice and ESX.PlayerData.job and ESX.PlayerData.job.name == Config.PoliceJobName then
								if Config.HotwireItemPoliceNeeded then
									ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
										if quantity > 0 then
											if Config.CanFailPolice then
												local fail = false
												local chance = Config.CanFailChancePolice
												local percent = math.random(100)
												local lock = GetVehicleDoorLockStatus(veh)
												local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
												if percent <= chance then
													exports['progressBars']:startUI(Config.HotwirePoliceTime*1000, _U('car_howtwireing'))
													Wait(Config.HotwirePoliceTime*1000)
													
													
													SetVehicleAlarm(veh, true)
													SetVehicleAlarmTimeLeft(veh, 30 * 1000)
													Wait(10)
													
													ESX.ShowNotification(_U('car_hotfailed'))
													TriggerServerEvent('parking:removeItem', Config.HotwireItemPolice)
													isHotwireing = false
													canHotwire = true
												else
													exports['progressBars']:startUI(Config.HotwirePoliceTime*1000, _U('car_howtwireing'))
													Wait(Config.HotwirePoliceTime*1000)
													 
													
													TriggerEvent('EngineToggle:Engine')
													ESX.ShowNotification(_U('car_hotwork'))
													isHotwireing = false
												end
											else
												exports['progressBars']:startUI(Config.HotwirePoliceTime*1000, _U('car_howtwireing'))
												Wait(Config.HotwirePoliceTime*1000)
												 
												
												TriggerEvent('EngineToggle:Engine')
												ESX.ShowNotification(_U('car_hotwork'))
												isHotwireing = false
											end
										else
											ESX.ShowNotification(_U('no_item'))
											isEnteringVehicle = false
										end
									end, Config.HotwireItemPolice)
								else
									exports['progressBars']:startUI(Config.HotwirePoliceTime*1000, _U('car_howtwireing'))
									Wait(Config.HotwirePoliceTime*1000)
									 
									
									TriggerEvent('EngineToggle:Engine')
									ESX.ShowNotification(_U('car_hotwork'))
									isHotwireing = false
								end
							elseif Config.EnableMechanic and ESX.PlayerData.job and ESX.PlayerData.job.name == Config.MechanicJobName then
								if Config.HotwireItemMechanicNeeded then
									ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
										if quantity > 0 then
											if Config.CanFailMechanic then
												local fail = false
												local chance = Config.CanFailChanceMechanic
												local percent = math.random(100)
												local lock = GetVehicleDoorLockStatus(veh)
												local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
												if percent <= chance then
													exports['progressBars']:startUI(Config.HotwireMechanicTime*1000, _U('car_howtwireing'))
													Wait(Config.HotwireMechanicTime*1000)
													
													
													SetVehicleAlarm(veh, true)
													SetVehicleAlarmTimeLeft(veh, 30 * 1000)
													Wait(10)
													
													ESX.ShowNotification(_U('car_hotfailed'))
													TriggerServerEvent('parking:removeItem', Config.HotwireItemMechanic)
													isHotwireing = false
													canHotwire = true
												else
													exports['progressBars']:startUI(Config.HotwireMechanicTime*1000, _U('car_howtwireing'))
													Wait(Config.HotwireMechanicTime*1000)
													 
													
													TriggerEvent('EngineToggle:Engine')
													ESX.ShowNotification(_U('car_hotwork'))
													isHotwireing = false
												end
											else
												exports['progressBars']:startUI(Config.HotwireMechanicTime*1000, _U('car_howtwireing'))
												Wait(Config.HotwireMechanicTime*1000)
												 
												
												TriggerEvent('EngineToggle:Engine')
												ESX.ShowNotification(_U('car_hotwork'))
												isHotwireing = false
											end
										else
											ESX.ShowNotification(_U('no_item'))
											isEnteringVehicle = false
										end
									end, Config.HotwireItemMechanic)
								else
									exports['progressBars']:startUI(Config.HotwireMechanicTime*1000, _U('car_howtwireing'))
									Wait(Config.HotwireMechanicTime*1000)
									 
									
									TriggerEvent('EngineToggle:Engine')
									ESX.ShowNotification(_U('car_hotwork'))
									isHotwireing = false
								end
							elseif Config.EnableCiv and not (ESX.PlayerData.job.name == Config.PoliceJobName) and not (ESX.PlayerData.job.name == Config.MechanicJobName) then
								if Config.HotwireItemCivNeeded then
									ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
										if quantity > 0 then
											if Config.CanFailCiv then
												local fail = false
												local chance = Config.CanFailChanceCiv
												local percent = math.random(100)
												local lock = GetVehicleDoorLockStatus(veh)
												local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
												if percent <= chance then
													exports['progressBars']:startUI(Config.HotwireCivTime*1000, _U('car_howtwireing'))
													Wait(Config.HotwireCivTime*1000)
													
													
													SetVehicleAlarm(veh, true)
													SetVehicleAlarmTimeLeft(veh, 30 * 1000)
													Wait(10)
													
													ESX.ShowNotification(_U('car_hotfailed'))
													TriggerServerEvent('parking:removeItem', Config.HotwireItemCiv)
													isHotwireing = false
													canHotwire = true
												else
													exports['progressBars']:startUI(Config.HotwireCivTime*1000, _U('car_howtwireing'))
													Wait(Config.HotwireCivTime*1000)
													 
													
													TriggerEvent('EngineToggle:Engine')
													ESX.ShowNotification(_U('car_hotwork'))
													isHotwireing = false
												end
											else
												exports['progressBars']:startUI(Config.HotwireCivTime*1000, _U('car_howtwireing'))
												Wait(Config.HotwireCivTime*1000)
												 
												
												TriggerEvent('EngineToggle:Engine')
												ESX.ShowNotification(_U('car_hotwork'))
												isHotwireing = false
											end
										else
											ESX.ShowNotification(_U('no_item'))
											isEnteringVehicle = false
										end
									end, Config.HotwireItemCiv)
								else
									exports['progressBars']:startUI(Config.HotwireCivTime*1000, _U('car_howtwireing'))
									Wait(Config.HotwireCivTime*1000)
									 
									
									TriggerEvent('EngineToggle:Engine')
									ESX.ShowNotification(_U('car_hotwork'))
									isHotwireing = false
								end
							end
						end
					end
				end, plate)
			else
				if not isInVehicle and IsControlJustPressed(0, Config.key1) and canLockpick and Config.EnableLockpick then
					
					isLockpicking = true
					canLockpick = false
					if Config.EnablePolice and ESX.PlayerData.job and ESX.PlayerData.job.name == Config.PoliceJobName then
						if Config.LockPickItemPoliceNeeded then
							ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
								if quantity > 0 then
									RequestAnimDict('anim@amb@clubhouse@tutorial@bkr_tut_ig3@')
									while not HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') do
										Citizen.Wait(0)
									end
									ESX.Streaming.RequestAnimDict("anim@amb@clubhouse@tutorial@bkr_tut_ig3@",function()
										TaskPlayAnim(GetPlayerPed(-1), 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@' , 'machinic_loop_mechandplayer' ,8.0, -8.0, -1, 1, 0, false, false, false )
									end)
									if Config.CanFailPolice then
										local fail = false
										local chance = Config.CanFailChancePolice
										local percent = math.random(100)
										local lock = GetVehicleDoorLockStatus(veh)
										local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
										if percent <= chance then
											exports['progressBars']:startUI(Config.LockpickPoliceTime*1000, _U('car_lockpicking'))
											Wait(Config.LockpickPoliceTime*1000)
											ClearPedTasksImmediately(ped)
											ClearPedTasks(ped)
											SetVehicleAlarm(veh, true)
											SetVehicleAlarmTimeLeft(veh, 30 * 1000)
											SetVehicleDoorsLocked(veh, 2)
											SetVehicleDoorsLockedForAllPlayers(veh, true)
											Wait(10)
											ClearPedTasksImmediately(ped) ClearPedTasks(ped)
											isEnteringVehicle = false
											ESX.ShowNotification(_U('car_failed'))
											TriggerServerEvent('parking:removeItem', Config.LockPickItemPolice)
											canLockpick = true
											isLockpicking = false
										else
											exports['progressBars']:startUI(Config.LockpickPoliceTime*1000, _U('car_lockpicking'))
											Wait(Config.LockpickPoliceTime*1000)
											ClearPedTasksImmediately(ped)
											SetVehicleDoorsLocked(veh, 1)
											SetVehicleDoorsLockedForAllPlayers(veh, false)
											Wait(10)
											isEnteringVehicle = false
											ESX.ShowNotification(_U('car_unlocked'))
											canHotwire = true
											isLockpicking = false
										end
									else
										exports['progressBars']:startUI(Config.LockpickPoliceTime*1000, _U('car_lockpicking'))
										Wait(Config.LockpickPoliceTime*1000)
										ClearPedTasksImmediately(ped) ClearPedTasks(ped)
										SetVehicleDoorsLocked(veh, 1)
										SetVehicleDoorsLockedForAllPlayers(veh, false)
										Wait(10)
										isEnteringVehicle = false
										ESX.ShowNotification(_U('car_unlocked'))
										canHotwire = true
										isLockpicking = false
									end
								else
									isLockpicking = false
									ESX.ShowNotification(_U('no_item'))
								end
							end, Config.LockPickItemPolice)
						else
							exports['progressBars']:startUI(Config.LockpickPoliceTime*1000, _U('car_lockpicking'))
							Wait(Config.LockpickPoliceTime*1000)
							ClearPedTasksImmediately(ped) ClearPedTasks(ped)
							SetVehicleDoorsLocked(veh, 1)
							SetVehicleDoorsLockedForAllPlayers(veh, false)
							Wait(10)
							isEnteringVehicle = false
							ESX.ShowNotification(_U('car_unlocked'))
							
							canHotwire = true
							isLockpicking = false
						end
					elseif Config.EnableMechanic and ESX.PlayerData.job and ESX.PlayerData.job.name == Config.MechanicJobName then
						if Config.LockPickItemMechanicNeeded then
							ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
								if quantity > 0 then
									RequestAnimDict('anim@amb@clubhouse@tutorial@bkr_tut_ig3@')
									while not HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') do
										Citizen.Wait(0)
									end
									ESX.Streaming.RequestAnimDict("anim@amb@clubhouse@tutorial@bkr_tut_ig3@",function()
										TaskPlayAnim(GetPlayerPed(-1), 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@' , 'machinic_loop_mechandplayer' ,8.0, -8.0, -1, 1, 0, false, false, false )
									end)
									if Config.CanFailMechanic then
										local fail = false
										local chance = Config.CanFailChanceMechanic
										local percent = math.random(100)
										local lock = GetVehicleDoorLockStatus(veh)
										local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
										if percent <= chance then
											exports['progressBars']:startUI(Config.LockpickMechanicTime*1000, _U('car_lockpicking'))
											Wait(Config.LockpickMechanicTime*1000)
											ClearPedTasksImmediately(ped)
											ClearPedTasks(ped)
											SetVehicleAlarm(veh, true)
											SetVehicleAlarmTimeLeft(veh, 30 * 1000)
											SetVehicleDoorsLocked(veh, 2)
											SetVehicleDoorsLockedForAllPlayers(veh, true)
											Wait(10)
											ClearPedTasksImmediately(ped) ClearPedTasks(ped)
											isEnteringVehicle = false
											ESX.ShowNotification(_U('car_failed'))
											TriggerServerEvent('parking:removeItem', Config.LockPickItemMechanic)
											isLockpicking = false
											canLockpick = true
										else
											exports['progressBars']:startUI(Config.LockpickMechanicTime*1000, _U('car_lockpicking'))
											Wait(Config.LockpickMechanicTime*1000)
											ClearPedTasksImmediately(ped)
											SetVehicleDoorsLocked(veh, 1)
											SetVehicleDoorsLockedForAllPlayers(veh, false)
											Wait(10)
											isEnteringVehicle = false
											ESX.ShowNotification(_U('car_unlocked'))
											isLockpicking = false
											canHotwire = true
										end
									else
										exports['progressBars']:startUI(Config.LockpickMechanicTime*1000, _U('car_lockpicking'))
										Wait(Config.LockpickMechanicTime*1000)
										ClearPedTasksImmediately(ped) ClearPedTasks(ped)
										SetVehicleDoorsLocked(veh, 1)
										SetVehicleDoorsLockedForAllPlayers(veh, false)
										Wait(10)
										isEnteringVehicle = false
										ESX.ShowNotification(_U('car_unlocked'))
										isLockpicking = false
										canHotwire = true
									end
								else
									isLockpicking = false
									ESX.ShowNotification(_U('no_item'))
								end
							end, Config.LockPickItemMechanic)
						else
							exports['progressBars']:startUI(Config.LockpickMechanicTime*1000, _U('car_lockpicking'))
							Wait(Config.LockpickMechanicTime*1000)
							ClearPedTasksImmediately(ped) ClearPedTasks(ped)
							SetVehicleDoorsLocked(veh, 1)
							SetVehicleDoorsLockedForAllPlayers(veh, false)
							Wait(10)
							isEnteringVehicle = false
							ESX.ShowNotification(_U('car_unlocked'))
							isLockpicking = false
							canHotwire = true
						end
					elseif Config.EnableCiv and not (ESX.PlayerData.job.name == Config.MechanicJobName) and not (ESX.PlayerData.job.name == Config.PoliceJobName) then
						if Config.LockPickItemCivNeeded then
							ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
								if quantity > 0 then
									RequestAnimDict('anim@amb@clubhouse@tutorial@bkr_tut_ig3@')
									while not HasAnimDictLoaded('anim@amb@clubhouse@tutorial@bkr_tut_ig3@') do
										Citizen.Wait(0)
									end
									ESX.Streaming.RequestAnimDict("anim@amb@clubhouse@tutorial@bkr_tut_ig3@",function()
										TaskPlayAnim(GetPlayerPed(-1), 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@' , 'machinic_loop_mechandplayer' ,8.0, -8.0, -1, 1, 0, false, false, false )
									end)
									if Config.CanFailCiv then
										local fail = false
										local chance = Config.CanFailChanceCiv
										local percent = math.random(100)
										local lock = GetVehicleDoorLockStatus(veh)
										local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
										if percent <= chance then
											exports['progressBars']:startUI(Config.LockpickCivTime*1000, _U('car_lockpicking'))
											Wait(Config.LockpickCivTime*1000)
											ClearPedTasksImmediately(ped)
											ClearPedTasks(ped)
											SetVehicleAlarm(veh, true)
											SetVehicleAlarmTimeLeft(veh, 30 * 1000)
											SetVehicleDoorsLocked(veh, 2)
											SetVehicleDoorsLockedForAllPlayers(veh, true)
											Wait(10)
											ClearPedTasksImmediately(ped) ClearPedTasks(ped)
											isEnteringVehicle = false
											ESX.ShowNotification(_U('car_failed'))
											TriggerServerEvent('parking:removeItem', Config.LockPickItemCiv)
											isLockpicking = false
											canLockpick = true
										else
											exports['progressBars']:startUI(Config.LockpickCivTime*1000, _U('car_lockpicking'))
											Wait(Config.LockpickCivTime*1000)
											ClearPedTasksImmediately(ped)
											SetVehicleDoorsLocked(veh, 1)
											SetVehicleDoorsLockedForAllPlayers(veh, false)
											Wait(10)
											isEnteringVehicle = false
											ESX.ShowNotification(_U('car_unlocked'))
											isLockpicking = false
											canHotwire = true
										end
									else
										exports['progressBars']:startUI(Config.LockpickCivTime*1000, _U('car_lockpicking'))
										Wait(Config.LockpickCivTime*1000)
										ClearPedTasksImmediately(ped) ClearPedTasks(ped)
										SetVehicleDoorsLocked(veh, 1)
										SetVehicleDoorsLockedForAllPlayers(veh, false)
										Wait(10)
										isEnteringVehicle = false
										ESX.ShowNotification(_U('car_unlocked'))
										isLockpicking = false
										canHotwire = true
									end
								else
									isLockpicking = false
									ESX.ShowNotification(_U('no_item'))
								end
							end, Config.LockPickItemCiv)
						else
							exports['progressBars']:startUI(Config.LockpickCivTime*1000, _U('car_lockpicking'))
							Wait(Config.LockpickCivTime*1000)
							ClearPedTasksImmediately(ped) ClearPedTasks(ped)
							SetVehicleDoorsLocked(veh, 1)
							SetVehicleDoorsLockedForAllPlayers(veh, false)
							Wait(10)
							isEnteringVehicle = false
							ESX.ShowNotification(_U('car_unlocked'))
							isLockpicking = false
							canHotwire = true
						end
					end
				end
				if isInVehicle and IsControlJustPressed(0, Config.key2) and canHotwire and Config.EnableHotwire and isInVehicle then
					
					canHotwire = false
					isHotwireing = true
					if Config.EnablePolice and ESX.PlayerData.job and ESX.PlayerData.job.name == Config.PoliceJobName then
						if Config.HotwireItemPoliceNeeded then
							ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
								if quantity > 0 then
									if Config.CanFailPolice then
										local fail = false
										local chance = Config.CanFailChancePolice
										local percent = math.random(100)
										local lock = GetVehicleDoorLockStatus(veh)
										local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
										if percent <= chance then
											exports['progressBars']:startUI(Config.HotwirePoliceTime*1000, _U('car_howtwireing'))
											Wait(Config.HotwirePoliceTime*1000)
											
											
											SetVehicleAlarm(veh, true)
											SetVehicleAlarmTimeLeft(veh, 30 * 1000)
											Wait(10)
											
											ESX.ShowNotification(_U('car_hotfailed'))
											TriggerServerEvent('parking:removeItem', Config.HotwireItemPolice)
											isHotwireing = false
											canHotwire = true
										else
											exports['progressBars']:startUI(Config.HotwirePoliceTime*1000, _U('car_howtwireing'))
											Wait(Config.HotwirePoliceTime*1000)
											 
											
											TriggerEvent('EngineToggle:Engine')
											ESX.ShowNotification(_U('car_hotwork'))
											isHotwireing = false
										end
									else
										exports['progressBars']:startUI(Config.HotwirePoliceTime*1000, _U('car_howtwireing'))
										Wait(Config.HotwirePoliceTime*1000)
										 
										
										TriggerEvent('EngineToggle:Engine')
										ESX.ShowNotification(_U('car_hotwork'))
										isHotwireing = false
									end
								else
									ESX.ShowNotification(_U('no_item'))
									isEnteringVehicle = false
									isHotwireing = false
								end
							end, Config.HotwireItemPolice)
						else
							exports['progressBars']:startUI(Config.HotwirePoliceTime*1000, _U('car_howtwireing'))
							Wait(Config.HotwirePoliceTime*1000)
							 
							
							TriggerEvent('EngineToggle:Engine')
							ESX.ShowNotification(_U('car_hotwork'))
							isHotwireing = false
						end
					elseif Config.EnableMechanic and ESX.PlayerData.job and ESX.PlayerData.job.name == Config.MechanicJobName then
						if Config.HotwireItemMechanicNeeded then
							ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
								if quantity > 0 then
									if Config.CanFailMechanic then
										local fail = false
										local chance = Config.CanFailChanceMechanic
										local percent = math.random(100)
										local lock = GetVehicleDoorLockStatus(veh)
										local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
										if percent <= chance then
											exports['progressBars']:startUI(Config.HotwireMechanicTime*1000, _U('car_howtwireing'))
											Wait(Config.HotwireMechanicTime*1000)
											
											
											SetVehicleAlarm(veh, true)
											SetVehicleAlarmTimeLeft(veh, 30 * 1000)
											Wait(10)
											
											ESX.ShowNotification(_U('car_hotfailed'))
											TriggerServerEvent('parking:removeItem', Config.HotwireItemMechanic)
											isHotwireing = false
											canHotwire = true
										else
											exports['progressBars']:startUI(Config.HotwireMechanicTime*1000, _U('car_howtwireing'))
											Wait(Config.HotwireMechanicTime*1000)
											 
											
											TriggerEvent('EngineToggle:Engine')
											ESX.ShowNotification(_U('car_hotwork'))
											isHotwireing = false
										end
									else
										exports['progressBars']:startUI(Config.HotwireMechanicTime*1000, _U('car_howtwireing'))
										Wait(Config.HotwireMechanicTime*1000)
										 
										
										TriggerEvent('EngineToggle:Engine')
										ESX.ShowNotification(_U('car_hotwork'))
										isHotwireing = false
									end
								else
									ESX.ShowNotification(_U('no_item'))
									isEnteringVehicle = false
									isHotwireing = false
								end
							end, Config.HotwireItemMechanic)
						else
							exports['progressBars']:startUI(Config.HotwireMechanicTime*1000, _U('car_howtwireing'))
							Wait(Config.HotwireMechanicTime*1000)
							 
							
							TriggerEvent('EngineToggle:Engine')
							ESX.ShowNotification(_U('car_hotwork'))
							isHotwireing = false
						end
					elseif Config.EnableCiv and not (ESX.PlayerData.job.name == Config.PoliceJobName) and not (ESX.PlayerData.job.name == Config.MechanicJobName) then
						if Config.HotwireItemCivNeeded then
							ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
								if quantity > 0 then
									if Config.CanFailCiv then
										local fail = false
										local chance = Config.CanFailChanceCiv
										local percent = math.random(100)
										local lock = GetVehicleDoorLockStatus(veh)
										local locked = GetVehicleDoorsLockedForPlayer(veh, ped)
										if percent <= chance then
											exports['progressBars']:startUI(Config.HotwireCivTime*1000, _U('car_howtwireing'))
											Wait(Config.HotwireCivTime*1000)
											
											
											SetVehicleAlarm(veh, true)
											SetVehicleAlarmTimeLeft(veh, 30 * 1000)
											Wait(10)
											
											ESX.ShowNotification(_U('car_hotfailed'))
											TriggerServerEvent('parking:removeItem', Config.HotwireItemCiv)
											isHotwireing = false
											canHotwire = true
										else
											exports['progressBars']:startUI(Config.HotwireCivTime*1000, _U('car_howtwireing'))
											Wait(Config.HotwireCivTime*1000)
											 
											
											TriggerEvent('EngineToggle:Engine')
											ESX.ShowNotification(_U('car_hotwork'))
											isHotwireing = false
										end
									else
										exports['progressBars']:startUI(Config.HotwireCivTime*1000, _U('car_howtwireing'))
										Wait(Config.HotwireCivTime*1000)
										 
										
										TriggerEvent('EngineToggle:Engine')
										ESX.ShowNotification(_U('car_hotwork'))
										isHotwireing = false
									end
								else
									ESX.ShowNotification(_U('no_item'))
									isEnteringVehicle = false
									isHotwireing = false
								end
							end, Config.HotwireItemCiv)
						else
							exports['progressBars']:startUI(Config.HotwireCivTime*1000, _U('car_howtwireing'))
							Wait(Config.HotwireCivTime*1000)
							 
							
							TriggerEvent('EngineToggle:Engine')
							ESX.ShowNotification(_U('car_hotwork'))
							isHotwireing = false
						end
					end
				end
			end
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		local ped = PlayerPedId()
		local ppos = GetEntityCoords(ped)
		local veh = GetClosestVehicle(ppos, 2.5, 0, 70)
		local vpos = GetEntityCoords(veh)
		local distance = GetDistanceBetweenCoords(ppos, vpos, false)
		local isInVehicle = IsPedInAnyVehicle(ped)
		Wait(10)
		if vehicleGPS and not isInVehicle and distance <= 2.5 then
			Wait(10)
			ESX.ShowHelpNotification(_U('install_gps'));
		end
		if vehicleNoGPS and not isInVehicle and distance <= 2.5 then
			Wait(10)
			ESX.ShowHelpNotification(_U('uninstall_gps'));
		end
		if PlayerLoaded then
			if not isInVehicle and Config.UseParkingGPSsystem and Config.EnableGPS and distance <= 2.5 then
				if Config.UseInstallJobs and Config.UseUninstallJobs then
					ESX.TriggerServerCallback('parking:InstallJobs', function(hasInstallJob)
						if hasInstallJob then
							canInstallGPS = true
						else
							canInstallGPS = false
						end
					end)
					ESX.TriggerServerCallback('parking:UninstallJobs', function(hasUninstallJob)
						if hasUninstallJob then
							canUninstallGPS = true
						else
							canUninstallGPS = false
						end
					end)
				elseif Config.UseInstallJobs and not Config.UseUninstallJobs then
					canUninstallGPS = true
					ESX.TriggerServerCallback('parking:InstallJobs', function(hasInstallJob)
						if hasInstallJob then
							canInstallGPS = true
						else
							canInstallGPS = false
						end
					end)
				elseif not Config.UseInstallJobs and Config.UseUninstallJobs then
					canInstallGPS = true
					ESX.TriggerServerCallback('parking:UninstallJobs', function(hasUninstallJob)
						if hasUninstallJob then
							canUninstallGPS = true
						else
							canUninstallGPS = false
						end
					end)
				elseif not Config.UseInstallJobs and not Config.UseUninstallJobs then
					canUninstallGPS = true
					canInstallGPS = true
				end
			else
				canUninstallGPS = false
				canInstallGPS = false
			end
			local plate = GetVehicleNumberPlateText(veh)
			ESX.TriggerServerCallback('parking:CheckVehicleGPS', function(getgps)
				if getgps then
					vehicleGPS = true
					vehicleNoGPS = false
				else
					vehicleGPS = false
					vehicleNoGPS = true
				end
			end, plate)
			if not isInVehicle and distance <= 2.5 and IsControlJustPressed(0, Config.key5) then
				ESX.TriggerServerCallback('parking:CheckVehicleGPS', function(getgps)
					if getgps then
						if canUninstallGPS then
							if Config.NeedUninstallItem then
								ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
									if quantity > 0 then
										isInstalling = true
										exports['progressBars']:startUI(Config.UninstallGPSTime*1000, _U('uninstalling_gps'))
										Wait(Config.UninstallGPSTime*1000)
										TriggerServerEvent('parking:GPSTracker', false, plate)
										ESX.ShowNotification(_U('uninstalled_gps'));
										isInstalling = false
									else
										ESX.ShowNotification(_U('no_item'));
									end
								end, Config.UninstallItem)
							else
								isInstalling = true
								exports['progressBars']:startUI(Config.UninstallGPSTime*1000, _U('uninstalling_gps'))
								Wait(Config.UninstallGPSTime*1000)
								TriggerServerEvent('parking:GPSTracker', false, plate)
								ESX.ShowNotification(_U('uninstalled_gps'));
								isInstalling = false
							end
						end
					else
						if canInstallGPS then
							if Config.NeedInstallItem then
								ESX.TriggerServerCallback('parking:getItemAmount', function(quantity)
									if quantity > 0 then
										isInstalling = true
										exports['progressBars']:startUI(Config.InstallGPSTime*1000, _U('installing_gps'))
										Wait(Config.InstallGPSTime*1000)
										TriggerServerEvent('parking:GPSTracker', false, plate)
										ESX.ShowNotification(_U('installed_gps'));
										isInstalling = false
									else
										ESX.ShowNotification(_U('no_item'));
									end
								end, Config.InstallItem)
							else
								isInstalling = true
								exports['progressBars']:startUI(Config.InstallGPSTime*1000, _U('installing_gps'))
								Wait(Config.InstallGPSTime*1000)
								TriggerServerEvent('parking:GPSTracker', false, plate)
								ESX.ShowNotification(_U('installed_gps'));
								isInstalling = false
							end
						end
					end
				end, plate)
			end
		end
	end
end)

Citizen.CreateThread(function()
    while true do
		Citizen.Wait(0)
		local ped = PlayerPedId()
		local ppos = GetEntityCoords(ped)
		local veh2 = GetClosestVehicle(ppos, Config.DistanceToUnlock, 0, 70)
		local vpos2 = GetEntityCoords(veh2)
		local distance2 = GetDistanceBetweenCoords(ppos, vpos2, false)
		if PlayerLoaded then
			if Config.EnableLockCar and IsControlJustPressed(0, Config.key4) and distance2 <= Config.DistanceToUnlock then
				veh = veh2
				lock = GetVehicleDoorLockStatus(veh)
				locked = GetVehicleDoorsLockedForPlayer(veh, ped)
				Wait(10)
				if Config.LockOnlyOwned then
					plate = ESX.Math.Trim(GetVehicleNumberPlateText(veh))
					ESX.TriggerServerCallback('parking:isVehicleOwner', function(owned)
						if owned then
							if lock == 2 then
								SetVehicleDoorsLocked(veh, 1)
								PlayVehicleDoorOpenSound(veh, 0)
								if not IsPedInAnyVehicle(PlayerPedId(), true) then
									TaskPlayAnim(PlayerPedId(), dict, "fob_click_fp", 8.0, 8.0, -1, 48, 1, false, false, false)
								end
								SetVehicleLights(veh, 2)
								Citizen.Wait(150)
								SetVehicleLights(veh, 0)
								Citizen.Wait(150)
								SetVehicleLights(veh, 2)
								Citizen.Wait(150)
								SetVehicleLights(veh, 0)
								SetVehicleDoorsLockedForAllPlayers(veh, false)
								ESX.ShowHelpNotification(_U('unlock_car'));
								local vehProps = ESX.Game.GetVehicleProperties(veh)
								local plate = vehProps.plate
								local vehPos = GetEntityCoords(veh)
								local headings = GetEntityHeading(veh)
								local coords = {
									x = vehPos.x,
									y = vehPos.y,
									z = vehPos.z, 
									heading = headings
								}
								local locked = false
								local engine = true
								if Config.EnableToggleEngine then
									if GetIsVehicleEngineRunning(veh) then
										engine = false
									else
										engine = true
									end
								end
								hotwired = hotwired
								local parked = false
								if not gps then
									ESX.TriggerServerCallback('parking:CheckVehicleGPS', function(getgps)
										if getgps then
											gps = true
										else
											gps = false
										end
									end,plate)
								end
								local vehProps = ESX.Game.GetVehicleProperties(veh)
								local plate = vehProps.plate
								local vehPos = GetEntityCoords(veh)
								local headings = GetEntityHeading(veh)
								local coords = {
									x = vehPos.x,
									y = vehPos.y,
									z = vehPos.z, 
									heading = headings
								}
								local locked = true
								local engine = true
								if Config.EnableToggleEngine then
									if GetIsVehicleEngineRunning(veh) then
										engine = false
									else
										engine = true
									end
								end
								hotwired = hotwired
								local parked = false
								if not gps then
									ESX.TriggerServerCallback('parking:CheckVehicleGPS', function(getgps)
										if getgps then
											gps = true
										else
											gps = false
										end
									end,plate)
								end
								TriggerServerEvent('parking:ParkVehicle', plate, vehProps, coords, locked, hotwired, parked, engine, gps )
							elseif lock == 1 or lock == 0 then
								SetVehicleDoorShut(veh, 0, false)
								SetVehicleDoorShut(veh, 1, false)
								SetVehicleDoorShut(veh, 2, false)
								SetVehicleDoorShut(veh, 3, false)
								SetVehicleDoorsLocked(veh, 2)
								PlayVehicleDoorCloseSound(veh, 1)
								if not IsPedInAnyVehicle(PlayerPedId(), true) then
									TaskPlayAnim(PlayerPedId(), dict, "fob_click_fp", 8.0, 8.0, -1, 48, 1, false, false, false)
								end
								SetVehicleLights(veh, 2)
								Citizen.Wait(150)
								SetVehicleLights(veh, 0)
								Citizen.Wait(150)
								SetVehicleLights(veh, 2)
								Citizen.Wait(150)
								SetVehicleLights(veh, 0)
								SetVehicleDoorsLockedForAllPlayers(veh, true)
								ESX.ShowHelpNotification(_U('lock_car'));
								local vehProps = ESX.Game.GetVehicleProperties(veh)
								local plate = vehProps.plate
								local vehPos = GetEntityCoords(veh)
								local headings = GetEntityHeading(veh)
								local coords = {
									x = vehPos.x,
									y = vehPos.y,
									z = vehPos.z, 
									heading = headings
								}
								local locked = true
								local engine = true
								if Config.EnableToggleEngine then
									if GetIsVehicleEngineRunning(veh) then
										engine = false
									else
										engine = true
									end
								end
								hotwired = hotwired
								local parked = false
								if not gps then
									ESX.TriggerServerCallback('parking:CheckVehicleGPS', function(getgps)
										if getgps then
											gps = true
										else
											gps = false
										end
									end,plate)
								end
								TriggerServerEvent('parking:ParkVehicle', plate, vehProps, coords, locked, hotwired, parked, engine, gps )
							end
						end
					end, plate)
				else
					if lock == 2 then
						SetVehicleDoorsLocked(veh, 1)
						PlayVehicleDoorOpenSound(veh, 0)
						if not IsPedInAnyVehicle(PlayerPedId(), true) then
							TaskPlayAnim(PlayerPedId(), dict, "fob_click_fp", 8.0, 8.0, -1, 48, 1, false, false, false)
						end
						SetVehicleLights(veh, 2)
						Citizen.Wait(150)
						SetVehicleLights(veh, 0)
						Citizen.Wait(150)
						SetVehicleLights(veh, 2)
						Citizen.Wait(150)
						SetVehicleLights(veh, 0)
						SetVehicleDoorsLockedForAllPlayers(veh, false)
						ESX.ShowHelpNotification(_U('unlock_car'));
					elseif lock == 1 or lock == 0 then
						SetVehicleDoorShut(veh, 0, false)
						SetVehicleDoorShut(veh, 1, false)
						SetVehicleDoorShut(veh, 2, false)
						SetVehicleDoorShut(veh, 3, false)
						SetVehicleDoorsLocked(veh, 2)
						PlayVehicleDoorCloseSound(veh, 1)
						if not IsPedInAnyVehicle(PlayerPedId(), true) then
							TaskPlayAnim(PlayerPedId(), dict, "fob_click_fp", 8.0, 8.0, -1, 48, 1, false, false, false)
						end
						SetVehicleLights(veh, 2)
						Citizen.Wait(150)
						SetVehicleLights(veh, 0)
						Citizen.Wait(150)
						SetVehicleLights(veh, 2)
						Citizen.Wait(150)
						SetVehicleLights(veh, 0)
						SetVehicleDoorsLockedForAllPlayers(veh, true)
						ESX.ShowHelpNotification(_U('lock_car'));
					end
				end
			end
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if PlayerLoaded then
			if Config.EnableToggleEngine then
				if IsControlJustReleased(1, Config.key3) then
					TriggerEvent('EngineToggle:Engine')
				end
			end
			if GetSeatPedIsTryingToEnter(GetPlayerPed(-1)) == -1 and not table.contains(vehicles, GetVehiclePedIsTryingToEnter(GetPlayerPed(-1))) then
				table.insert(vehicles, {GetVehiclePedIsTryingToEnter(GetPlayerPed(-1)), IsVehicleEngineOn(GetVehiclePedIsTryingToEnter(GetPlayerPed(-1)))})
			elseif IsPedInAnyVehicle(GetPlayerPed(-1), false) and not table.contains(vehicles, GetVehiclePedIsIn(GetPlayerPed(-1), false)) then
				table.insert(vehicles, {GetVehiclePedIsIn(GetPlayerPed(-1), false), IsVehicleEngineOn(GetVehiclePedIsIn(GetPlayerPed(-1), false))})
			end
			for i, vehicle in ipairs(vehicles) do
				if DoesEntityExist(vehicle[1]) then
					if (GetPedInVehicleSeat(vehicle[1], -1) == GetPlayerPed(-1)) or IsVehicleSeatFree(vehicle[1], -1) then
						if RPWorking then
							SetVehicleEngineOn(vehicle[1], vehicle[2], true, false)
							SetVehicleJetEngineOn(vehicle[1], vehicle[2])
							if not IsPedInAnyVehicle(GetPlayerPed(-1), false) or (IsPedInAnyVehicle(GetPlayerPed(-1), false) and vehicle[1]~= GetVehiclePedIsIn(GetPlayerPed(-1), false)) then
								if IsThisModelAHeli(GetEntityModel(vehicle[1])) or IsThisModelAPlane(GetEntityModel(vehicle[1])) then
									if vehicle[2] then
										SetHeliBladesFullSpeed(vehicle[1])
									end
								end
							end
						end
					end
				else
					table.remove(vehicles, i)
				end
			end
		end
	end
end)

function table.contains(table, element)
  for _, value in pairs(table) do
    if value[1] == element then
      return true
    end
  end
  return false
end

function ShowHelpNotification(text)
    ClearAllHelpMessages();
    SetTextComponentFormat("STRING");
    AddTextComponentString(text);
    DisplayHelpTextFromStringLabel(0, false, true, 5000);
end

function SetVehicleProperties (vehicle, props)
    if DoesEntityExist(vehicle) then
        local colorPrimary, colorSecondary = GetVehicleColours(vehicle)
        local pearlescentColor, wheelColor = GetVehicleExtraColours(vehicle)
        SetVehicleModKit(vehicle, 0)
 
        if props.plate then SetVehicleNumberPlateText(vehicle, props.plate) end
        if props.plateIndex then SetVehicleNumberPlateTextIndex(vehicle, props.plateIndex) end
        if props.bodyHealth then SetVehicleBodyHealth(vehicle, props.bodyHealth + 0.0) end
        if props.engineHealth then SetVehicleEngineHealth(vehicle, props.engineHealth + 0.0) end
        if props.tankHealth then SetVehiclePetrolTankHealth(vehicle, props.tankHealth + 0.0) end
        if props.fuelLevel then SetVehicleFuelLevel(vehicle, props.fuelLevel + 0.0) end
        if props.dirtLevel then SetVehicleDirtLevel(vehicle, props.dirtLevel + 0.0) end
        if props.color1 then SetVehicleColours(vehicle, props.color1, colorSecondary) end
        if props.color2 then SetVehicleColours(vehicle, props.color1 or colorPrimary, props.color2) end
        if props.pearlescentColor then SetVehicleExtraColours(vehicle, props.pearlescentColor, wheelColor) end
        if props.wheelColor then SetVehicleExtraColours(vehicle, props.pearlescentColor or pearlescentColor, props.wheelColor) end
        if props.wheels then SetVehicleWheelType(vehicle, props.wheels) end
        if props.windowTint then SetVehicleWindowTint(vehicle, props.windowTint) end
 
        if props.neonEnabled then
            SetVehicleNeonLightEnabled(vehicle, 0, props.neonEnabled[1])
            SetVehicleNeonLightEnabled(vehicle, 1, props.neonEnabled[2])
            SetVehicleNeonLightEnabled(vehicle, 2, props.neonEnabled[3])
            SetVehicleNeonLightEnabled(vehicle, 3, props.neonEnabled[4])
        end
 
        if props.extras then
            for extraId,enabled in pairs(props.extras) do
                if enabled then
                    SetVehicleExtra(vehicle, tonumber(extraId), 0)
                else
                    SetVehicleExtra(vehicle, tonumber(extraId), 1)
                end
            end
        end
 
        if props.neonColor then SetVehicleNeonLightsColour(vehicle, props.neonColor[1], props.neonColor[2], props.neonColor[3]) end
        if props.xenonColor then SetVehicleXenonLightsColour(vehicle, props.xenonColor) end
        if props.modSmokeEnabled then ToggleVehicleMod(vehicle, 20, true) end
        if props.tyreSmokeColor then SetVehicleTyreSmokeColor(vehicle, props.tyreSmokeColor[1], props.tyreSmokeColor[2], props.tyreSmokeColor[3]) end
        if props.modSpoilers then SetVehicleMod(vehicle, 0, props.modSpoilers, false) end
        if props.modFrontBumper then SetVehicleMod(vehicle, 1, props.modFrontBumper, false) end
        if props.modRearBumper then SetVehicleMod(vehicle, 2, props.modRearBumper, false) end
        if props.modSideSkirt then SetVehicleMod(vehicle, 3, props.modSideSkirt, false) end
        if props.modExhaust then SetVehicleMod(vehicle, 4, props.modExhaust, false) end
        if props.modFrame then SetVehicleMod(vehicle, 5, props.modFrame, false) end
        if props.modGrille then SetVehicleMod(vehicle, 6, props.modGrille, false) end
        if props.modHood then SetVehicleMod(vehicle, 7, props.modHood, false) end
        if props.modFender then SetVehicleMod(vehicle, 8, props.modFender, false) end
        if props.modRightFender then SetVehicleMod(vehicle, 9, props.modRightFender, false) end
        if props.modRoof then SetVehicleMod(vehicle, 10, props.modRoof, false) end
        if props.modEngine then SetVehicleMod(vehicle, 11, props.modEngine, false) end
        if props.modBrakes then SetVehicleMod(vehicle, 12, props.modBrakes, false) end
        if props.modTransmission then SetVehicleMod(vehicle, 13, props.modTransmission, false) end
        if props.modHorns then SetVehicleMod(vehicle, 14, props.modHorns, false) end
        if props.modSuspension then SetVehicleMod(vehicle, 15, props.modSuspension, false) end
        if props.modArmor then SetVehicleMod(vehicle, 16, props.modArmor, false) end
        if props.modTurbo then ToggleVehicleMod(vehicle,  18, props.modTurbo) end
        if props.modXenon then ToggleVehicleMod(vehicle,  22, props.modXenon) end
        if props.modFrontWheels then SetVehicleMod(vehicle, 23, props.modFrontWheels, false) end
        if props.modBackWheels then SetVehicleMod(vehicle, 24, props.modBackWheels, false) end
        if props.modPlateHolder then SetVehicleMod(vehicle, 25, props.modPlateHolder, false) end
        if props.modVanityPlate then SetVehicleMod(vehicle, 26, props.modVanityPlate, false) end
        if props.modTrimA then SetVehicleMod(vehicle, 27, props.modTrimA, false) end
        if props.modOrnaments then SetVehicleMod(vehicle, 28, props.modOrnaments, false) end
        if props.modDashboard then SetVehicleMod(vehicle, 29, props.modDashboard, false) end
        if props.modDial then SetVehicleMod(vehicle, 30, props.modDial, false) end
        if props.modDoorSpeaker then SetVehicleMod(vehicle, 31, props.modDoorSpeaker, false) end
        if props.modSeats then SetVehicleMod(vehicle, 32, props.modSeats, false) end
        if props.modSteeringWheel then SetVehicleMod(vehicle, 33, props.modSteeringWheel, false) end
        if props.modShifterLeavers then SetVehicleMod(vehicle, 34, props.modShifterLeavers, false) end
        if props.modAPlate then SetVehicleMod(vehicle, 35, props.modAPlate, false) end
        if props.modSpeakers then SetVehicleMod(vehicle, 36, props.modSpeakers, false) end
        if props.modTrunk then SetVehicleMod(vehicle, 37, props.modTrunk, false) end
        if props.modHydrolic then SetVehicleMod(vehicle, 38, props.modHydrolic, false) end
        if props.modEngineBlock then SetVehicleMod(vehicle, 39, props.modEngineBlock, false) end
        if props.modAirFilter then SetVehicleMod(vehicle, 40, props.modAirFilter, false) end
        if props.modStruts then SetVehicleMod(vehicle, 41, props.modStruts, false) end
        if props.modArchCover then SetVehicleMod(vehicle, 42, props.modArchCover, false) end
        if props.modAerials then SetVehicleMod(vehicle, 43, props.modAerials, false) end
        if props.modTrimB then SetVehicleMod(vehicle, 44, props.modTrimB, false) end
        if props.modTank then SetVehicleMod(vehicle, 45, props.modTank, false) end
        if props.modWindows then SetVehicleMod(vehicle, 46, props.modWindows, false) end
 
        if props.modLivery then
            SetVehicleMod(vehicle, 48, props.modLivery, false)
            SetVehicleLivery(vehicle, props.modLivery)
        end
    end
end

RegisterNetEvent('parking:setVehicleDoors')
AddEventHandler('parking:setVehicleDoors', function(veh, doors)
  SetVehicleDoorsLocked(veh, doors)
  SetVehicleNeedsToBeHotwired(veh, false)
end)

RegisterNetEvent("parking:DeleteVehicles")
AddEventHandler("parking:DeleteVehicles", function (vehicles)
    for plate, vehicle in pairs (vehicles) do 
        if DoesEntityExist (vehicle) == true then
            DeleteVehicle(vehicle)
		end
    end
end)

RegisterNetEvent('parking:sendMessage')
AddEventHandler('parking:sendMessage', function(message)
	message = message
	ESX.ShowNotification(_U(message))
end)

RegisterNetEvent("PommesMitDoener:sendSound")
AddEventHandler("PommesMitDoener:sendSound", function()
	PlaySoundFrontend(-1, "ATM_WINDOW", "HUD_FRONTEND_DEFAULT_SOUNDSET")
end)

RegisterNetEvent('EngineToggle:Engine')
AddEventHandler('EngineToggle:Engine', function()
	local veh
	local StateIndex
	for i, vehicle in ipairs(vehicles) do
		if vehicle[1] == GetVehiclePedIsIn(GetPlayerPed(-1), false) then
			veh = vehicle[1]
			StateIndex = i
		end
	end

	if IsPedInAnyVehicle(GetPlayerPed(-1), false) then 
		if (GetPedInVehicleSeat(veh, -1) == GetPlayerPed(-1)) then
			vehicles[StateIndex][2] = not GetIsVehicleEngineRunning(veh)
			if vehicles[StateIndex][2] then
				TriggerEvent("PommesMitDoener:sendSound")
				ESX.ShowHelpNotification(_U('engine_started'));
			else
				TriggerEvent("PommesMitDoener:sendSound")
				ESX.ShowHelpNotification(_U('engine_stopped'));
			end
		end 
    end 
end)

RegisterNetEvent('EngineToggle:EngineStartup')
AddEventHandler('EngineToggle:EngineStartup', function(thisvehicle)
	local veh
	local StateIndex
	for i, vehicle in ipairs(vehicles) do
		if vehicle[1] == thisvehicle then
			veh = vehicle[1]
			StateIndex = i
		end
	end

	-- if IsPedInAnyVehicle(GetPlayerPed(-1), false) then 
		-- if (GetPedInVehicleSeat(veh, -1) == GetPlayerPed(-1)) then
			-- vehicles[StateIndex][2] = not GetIsVehicleEngineRunning(veh)
			-- if vehicles[StateIndex][2] then
				-- TriggerEvent("PommesMitDoener:sendSound")
				-- ESX.ShowHelpNotification(_U('engine_started'));
			-- else
				-- TriggerEvent("PommesMitDoener:sendSound")
				-- ESX.ShowHelpNotification(_U('engine_stopped'));
			-- end
		-- end 
    -- end 
end)

RegisterNetEvent('EngineToggle:RPDamage')
AddEventHandler('EngineToggle:RPDamage', function(State)
	RPWorking = State
end)

RegisterNetEvent('parking:startSetup')
AddEventHandler('parking:startSetup', function(test)
	ESX.ShowNotification(_U('start_setup'))
end)

RegisterNetEvent('parking:alreadySetup')
AddEventHandler('parking:alreadySetup', function(test)
	ESX.ShowNotification(_U('already_setup'))
end)

RegisterNetEvent('parking:failedSetup')
AddEventHandler('parking:failedSetup', function(test)
	ESX.ShowNotification(_U('failed_setup'))
end)

RegisterNetEvent('parking:endSetup')
AddEventHandler('parking:endSetup', function(test)
	ESX.ShowNotification(_U('end_setup'))
end)

RegisterNetEvent('parking:searchEnd')
AddEventHandler('parking:searchEnd', function(plate)
	searchVehicle = false
end)

RegisterNetEvent('parking:searchVehicle')
AddEventHandler('parking:searchVehicle', function(plate)
	Wait(1000)
	ESX.TriggerServerCallback('parking:CheckVehicleGPS', function(getgps)
		if getgps then
			searchPlate = plate
			if Config.EnableGPS then
				ESX.ShowNotification(_U('gps_search'))
				Wait(Config.NextScan*1000)
				searchVehicle = true
			end
		else
			ESX.ShowNotification(_U('no_gps'))
		end
	end, plate)
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(100)
		if searchVehicle then
			searchPosition = nil
			ESX.TriggerServerCallback('parking:CheckVehiclePosition', function(pos)
				if DoesBlipExist(blip) then
					RemoveBlip(blip)
				end
				searchVehicle = false
				Wait(100)
				searchPosition = json.decode(pos)
				blip = AddBlipForCoord(searchPosition.x, searchPosition.y, searchPosition.z)
				SetBlipSprite(blip, 225)
				SetBlipColour(blip, 0)
				SetBlipScale(blip,1.0)
				SetBlipAsShortRange(blip, true)
				BeginTextCommandSetBlipName("STRING")
				AddTextComponentString(''..searchPlate..'')
				EndTextCommandSetBlipName(blip)
				ESX.ShowNotification(_U('gps_active'))
				searchVehicle = true
			end, searchPlate)
			Wait(Config.NextScan*1000)
		else
			RemoveBlip(blip)
		end
	end
end)

RegisterNetEvent("parking:ResetVehicles")
AddEventHandler("parking:ResetVehicles", function ()
	ESX.TriggerServerCallback("parking:GetAllVehicles", function(vehicles)
		for i, v in pairs (vehicles) do 
			local vehPos = json.decode(v.pos)
			local vehProperties = json.decode(v.vehicle)
			local plate = v.plate
			if not Config.UseNPCcars then
				ESX.TriggerServerCallback('parking:CheckIfVehicleOwned', function(owned)
					if owned then
						ESX.TriggerServerCallback("parking:IfVehicleExist", function (vehiclesTable)
							if (not vehiclesTable[plate])then 
								if IsModelInCdimage(vehProperties.model) then
									local playerPed = PlayerPedId()
									Citizen.CreateThread(function()
										RequestModel (vehProperties.model) 
										while not HasModelLoaded(vehProperties.model) do
											Wait(200) 
										end
										local vehicle = CreateVehicle(vehProperties.model, vehPos.x, vehPos.y, vehPos.z, vehPos.heading, true, false)
										local networkId = NetworkGetNetworkIdFromEntity(vehicle)
							
										SetNetworkIdCanMigrate(networkId, true)
										SetEntityAsMissionEntity(vehicle,true ,false)
										SetVehicleHasBeenOwnedByPlayer(vehicle, true)
										SetVehicleNeedsToBeHotwired(vehicle, false)
										if Config.EnableToggleEngine then
											ESX.TriggerServerCallback('parking:CheckVehicleEngine', function(engine)
												if engine then
													SetVehicleEngineOn(vehicle, engine, true, true)
												else
													SetVehicleEngineOn(vehicle, engine, true, true)
												end
											end, plate)
										else
											SetVehicleEngineOn(vehicle, true, true, true)
										end
										SetVehicleProperties (vehicle, vehProperties)
										ESX.TriggerServerCallback('parking:CheckVehicleLocked', function(locked)
											if locked then
												SetVehicleDoorsLocked(vehicle, 2)
												SetVehicleDoorShut(vehicle, 0, false)
												SetVehicleDoorShut(vehicle, 1, false)
												SetVehicleDoorShut(vehicle, 2, false)
												SetVehicleDoorShut(vehicle, 3, false)
											else
												SetVehicleDoorsLocked(vehicle, 1)
												SetVehicleDoorLatched(vehicle, 0, true, false)
												SetVehicleDoorLatched(vehicle, 1, true, false)
												SetVehicleDoorLatched(vehicle, 2, true, false)
												SetVehicleDoorLatched(vehicle, 3, true, false)
											end
										end, plate)
										SetVehRadioStation(vehicle, 'OFF')
										SetModelAsNoLongerNeeded(vehProperties.model)
										TriggerServerEvent("parking:AddVehicleToTable", vehicle, plate)
										ESX.TriggerServerCallback('parking:CheckVehicleDate', function(datum)
										end, plate)
										ESX.TriggerServerCallback('parking:CheckVehicleExDate', function(datum)
											datum = datum
										end, plate)
									end)
								end
							end
						end)
					else
						TriggerServerEvent("parking:RemoveVehicleFromTable", plate)
						TriggerServerEvent("parking:RemoveVehicleFromDatabase", plate)
					end
				end, plate)
			else
				ESX.TriggerServerCallback("parking:IfVehicleExist", function (vehiclesTable)
					if (not vehiclesTable[plate])then 
						if IsModelInCdimage(vehProperties.model) then
							local playerPed = PlayerPedId()
							Citizen.CreateThread(function()
								RequestModel (vehProperties.model) 
								while not HasModelLoaded(vehProperties.model) do
									Wait(200) 
								end
								local vehicle = CreateVehicle(vehProperties.model, vehPos.x, vehPos.y, vehPos.z, vehPos.heading, true, false)
								local networkId = NetworkGetNetworkIdFromEntity(vehicle)
					
								SetNetworkIdCanMigrate(networkId, true)
								SetEntityAsMissionEntity(vehicle,true ,false)
								SetVehicleHasBeenOwnedByPlayer(vehicle, true)
								SetVehicleNeedsToBeHotwired(vehicle, false)
								if Config.EnableToggleEngine then
									ESX.TriggerServerCallback('parking:CheckVehicleEngine', function(engine)
										if engine then
											SetVehicleEngineOn(vehicle, engine, true, true)
										else
											SetVehicleEngineOn(vehicle, engine, true, true)
										end
									end, plate)
								else
									SetVehicleEngineOn(vehicle, true, true, true)
								end
								SetVehicleProperties (vehicle, vehProperties)
								ESX.TriggerServerCallback('parking:CheckVehicleLocked', function(locked)
									if locked then
										SetVehicleDoorsLocked(vehicle, 2)
										SetVehicleDoorShut(vehicle, 0, false)
										SetVehicleDoorShut(vehicle, 1, false)
										SetVehicleDoorShut(vehicle, 2, false)
										SetVehicleDoorShut(vehicle, 3, false)
									else
										SetVehicleDoorsLocked(vehicle, 1)
										SetVehicleDoorLatched(vehicle, 0, true, false)
										SetVehicleDoorLatched(vehicle, 1, true, false)
										SetVehicleDoorLatched(vehicle, 2, true, false)
										SetVehicleDoorLatched(vehicle, 3, true, false)
									end
								end, plate)
								SetVehRadioStation(vehicle, 'OFF')
								SetModelAsNoLongerNeeded(vehProperties.model)
								TriggerServerEvent("parking:AddVehicleToTable", vehicle, plate)
								ESX.TriggerServerCallback('parking:CheckVehicleDate', function(datum)
									datum = datum
								end, plate)
								ESX.TriggerServerCallback('parking:CheckVehicleExDate', function(datum)
									datum = datum
								end, plate)
							end)
						end
					end
				end)
			end
		end
	end)
end)