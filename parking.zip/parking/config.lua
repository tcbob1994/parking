Config = {}
--[[
	LOCALE SETTINGS
--]]

Config.Locale = 'en' -- de, rus, fr, es and en for now

-- !!!DISCLAIMER!!!
-- Locales are translated from engish to other languages!
-- feel free to edit them as you like if you like to have your language in write it to me and i add them

--[[
	Key Configuration
--]]

Config.key1 = 46 -- E -> Key for lockpicking the vehicle
Config.key2 = 46 -- E -> Key for hotwireing the vehicle
Config.key3 = 246 -- Z -> Key to toggle engine
Config.key4 = 303 -- U -> Key to toggle carlock
Config.key5 = 47 -- G -> Key to install gps tracker

--[[
	CONFIGURATION MAIN SETTINGS
--]]

Config.EnableLockpick = true -- Enables the hotwire function
Config.EnableHotwire = true -- Enables the lockpick function
Config.EnableToggleEngine = true -- Function to toggle the engine in cars << key3
Config.EnableLockCar = true -- Enable lock and unlock car with << key4
Config.EnableGPS = true -- Allow to use Gps function

--[[
	EXPANDED SETTINGS !! READ CAREFULLY !!
--]]

Config.DistanceToUnlock = 5.0 -- Distance to Lock and unlock cars // 5.0 is recommended
Config.PlayerGps = true -- Allows the Player to use gps command THIS WORKS ONLY FOR OWN VEHICLES! :)
Config.NextScan = 30 -- Scan intervall in seconds !30 is default for testing! 120 is recommended!
Config.JobGps = true -- Allows following jobs to use gps tracker
Config.WhitelistedJobs = { -- Jobs whitelisted to use gps tracker
	'police',
	'mafia',
}
Config.UseParkingGPSsystem = true -- You can use your own thing to install gps in cars if you dont like to use this
Config.NeedGpsItem = true -- toggle off to dont use a gps item
Config.GPSItem = 'gps_tracker' -- item to install gps system
Config.UseInstallJobs = true -- Allows the following jobs to install gps tracker
Config.InstallJobs = { -- Jobs whitelisted to install gps tracker
	'mechanic',
}
Config.InstallGPSTime = 30 -- time in seconds needed to uninstall gps tracker
Config.NeedUninstallItem = true -- toggle off to dont use a uninstall item
Config.UseUninstallJobs = true -- Allows the following jobs to uninstall gps tracker
Config.UninstallItem = 'wrench' -- item to install gps system
Config.UninstallJobs = { -- Jobs whitelisted to uninstall gps tracker
	'mechanic',
	'mafia',
}
Config.UninstallGPSTime = 30 -- time in seconds needed to install gps tracker
Config.EnablePolice = true -- Enables the hotwire function for police
Config.EnableMechanic = true -- Enables the hotwire function for mechanic
Config.EnableCiv = true -- Enables the hotwire function for civs
Config.PoliceJobName = 'police'
Config.MechanicJobName = 'mechanic'
Config.LockPickItemPoliceNeeded = true -- enables the item for lockpicking the car
Config.LockPickItemPolice = 'lockpick' -- Item to Lockpick (databasename)
Config.LockPickItemMechanicNeeded = true -- enables the item for lockpicking the car
Config.LockPickItemMechanic = 'lockpick' -- Item to Lockpick (databasename)
Config.LockPickItemCivNeeded = true -- enables the item for lockpicking the car
Config.LockPickItemCiv = 'lockpick' -- Item to Lockpick (databasename)
Config.HotwireItemPoliceNeeded = true -- enables the item for hotwireing the car
Config.HotwireItemPolice = 'lockpick' -- Item to hotwire (databasename)
Config.HotwireItemMechanicNeeded = true -- enables the item for hotwireing the car
Config.HotwireItemMechanic = 'lockpick' -- Item to hotwire (databasename)
Config.HotwireItemCivNeeded = true -- enables the item for hotwireing the car
Config.HotwireItemCiv = 'lockpick' -- Item to hotwire (databasename)
Config.CanFailPolice = true -- Can the lockpicking and hotwireing fail?
Config.CanFailChancePolice = 25 -- What is the chance to fail in percent?
Config.CanFailMechanic = true -- Can the lockpicking and hotwireing fail?
Config.CanFailChanceMechanic = 25 -- What is the chance to fail in percent?
Config.CanFailCiv = true -- Can the lockpicking and hotwireing fail?
Config.CanFailChanceCiv = 25 -- What is the chance to fail in percent?
Config.LockpickPoliceTime = 10 -- Time needed to lockpick the car in seconds
Config.LockpickMechanicTime = 10 -- Time needed to lockpick the car in seconds
Config.LockpickCivTime = 10 -- Time needed to lockpick the car in seconds
Config.HotwirePoliceTime = 10 -- Time needed to hotwire the car in seconds
Config.HotwireMechanicTime = 10 -- Time needed to hotwire the car in seconds
Config.HotwireCivTime = 10 -- Time needed to hotwire the car in seconds

--[[
	DEBUG AND SERVER CONFIGURATION
--]]

Config.DebugMSG = true -- Debug Option for Testing. Shows the Debug Messages.
Config.EnableSlowMode = true -- Slowmode for slow Servers
Config.SlowModeTime = 8 -- Seconds to wait for Slowmode
Config.Garages = true -- true if you using the old parking system. AdvancedGarage NEEDS TO BE FALSE!!!
Config.AdvancedGarage = false -- ONLY WORKS WITH esx_advancedgarage! GARAGES NEEDS TO BE FALSE
Config.LockOnlyOwned = true -- Allows to lock only owned cars
Config.UseNPCcars = true -- true !!! ONLY ON NEW INSTALLATION OR IF parking TABLE IS EMPTY!!! means you can also park/hotwire/lockpick npc cars!!!!
Config.adminRanks = {
	'superadmin',
	'admin',
	'moderator',
}