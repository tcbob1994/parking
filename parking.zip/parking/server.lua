ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
local vehiclesRespawned = {}
local vehicles = {}
local firstplayer = true
local SetupComplete = false
local CurrentVersion = '12.0'
local isUptoDate = false

PerformHttpRequest("https://raw.githubusercontent.com/tcbob1994/parking/main/VERSION.md", function(Error, NewVersion, Header)
	if CurrentVersion ~= NewVersion and tonumber(CurrentVersion) < tonumber(NewVersion) then
		print("\n")
		print("####")
		print("#### Parking System")
		print("####")
		print("#### ^4Current Version: " .. CurrentVersion .. "^4")
		print("#### ^5Newest Version: " .. NewVersion .. "^5")
		print("####")
		print("#### ^4Outdated^4, please download the newest Version!")
		print("####")
		print("\n")
		isUptoDate = false
	else
		print("\n")
		print("####")
		print("#### Parking System")
		print("####")
		print("#### ^4Current Version: " .. CurrentVersion .. "^4")
		print("#### ^5Newest Version: " .. NewVersion .. "^5")
		print("####")
		print("#### ^4Everything is Up to date! ^4")
		print("####")
		print("\n")
		isUptoDate = true
	end
end)

ESX.RegisterServerCallback('parking:CheckIfVehicleOwned', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM owned_vehicles WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		if vehicle[1] then
            cb(true)
        else
			if Config.Debug then
				cb(true)
			else
				cb(false)
			end
        end
    end)
end)

ESX.RegisterServerCallback('parking:CheckVersion', function(source, cb)
	cb(CurrentVersion)
end)

ESX.RegisterServerCallback('parking:CheckNewVersion', function(source, cb)
	cb(isUptoDate)
end)
 

ESX.RegisterServerCallback('parking:CheckVehicleLocked', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local locked = vehicle[i].locked
			if locked then
				cb(true)
			else
				cb(false)
			end
		end
    end)
end)

ESX.RegisterServerCallback('parking:CheckVehicleHotwired', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local hotwired = vehicle[i].hotwired
			if hotwired then
				cb(true)
			else
				cb(false)
			end
		end
    end)
end)

ESX.RegisterServerCallback('parking:GetVehicle', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local vehicle = vehicle[i].vehicle
			cb(vehicle)
		end
    end)
end)

ESX.RegisterServerCallback('parking:CheckVehicleParked', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local parked = vehicle[i].parked
			if parked then
				cb(true)
			else
				cb(false)
			end
		end
    end)
end)

ESX.RegisterServerCallback('parking:CheckVehicleEngine', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local engine = vehicle[i].engine
			if engine == 1 then
				cb(true)
			else
				cb(false)
			end
		end
    end)
end)

ESX.RegisterServerCallback('parking:CheckVehicleLockpicked', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local lockpicked = vehicle[i].lockpicked
			if lockpicked == 1 then
				cb(true)
			else
				cb(false)
			end
		end
    end)
end)

ESX.RegisterServerCallback('parking:CheckVehicleDate', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local datum = vehicle[i].date
			cb(datum)
		end
    end)
end)

ESX.RegisterServerCallback('parking:CheckVehicleExDate', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local datum = vehicle[i].expiredate
			cb(datum)
		end
    end)
end)

ESX.RegisterServerCallback('parking:CheckVehicleGPS', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local gps = vehicle[i].gps
			if gps then
				cb(true)
			else
				cb(false)
			end
		end
    end)
end)

ESX.RegisterServerCallback('parking:CheckVehiclePosition', function(source, cb, plate)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
        plate = plate
		for i=1, #vehicle, 1 do
			local pos = vehicle[i].pos
			cb(pos)
		end
    end)
end)

function getVehData(plate, callback)
	MySQL.Async.fetchAll("SELECT * FROM `owned_vehicles`", {},
	function(result)
		local foundIdentifier = nil
		for i=1, #result, 1 do
			local vehicleData = json.decode(result[i].vehicle)
			if vehicleData.plate == plate then
				foundIdentifier = result[i].owner
				break
			end
		end
		if foundIdentifier ~= nil then
			MySQL.Async.fetchAll("SELECT * FROM `users` WHERE `identifier` = @identifier", {['@identifier'] = foundIdentifier},
			function(result)
				local ownerName = result[1].firstname .. " " .. result[1].lastname

				local info = {
					plate = plate,
					owner = ownerName
				}
				callback(info)
			end
		  )
		else -- if identifier is nil then...
		  local info = {
			plate = plate
		  }
		  callback(info)
		end
	end)
end

RegisterNetEvent("parking:setVehicleDoorsForEveryone")
AddEventHandler("parking:setVehicleDoorsForEveryone", function(veh, doors, plate)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local veh_model = veh[1]
    local veh_doors = veh[2]
    local veh_plate = veh[3]

    if not vehiclesRespawned[veh_plate] then
        getVehData(veh_plate, function(veh_data)
            if veh_data.plate ~= plate then
                local players = GetPlayers()
                for _,player in pairs(players) do
                    TriggerClientEvent("parking:setVehicleDoors", player, table.unpack(veh, doors))
                end
            end
        end)
        vehiclesRespawned[veh_plate] = true
    end
end)

ESX.RegisterServerCallback('parking:isVehicleOwner', function(source, cb, plate)
	if source ~= 0 then
		local xPlayer = ESX.GetPlayerFromId(source)
		MySQL.Async.fetchAll('SELECT 1 FROM owned_vehicles WHERE owner = @owner AND plate = @plate', {
			['@owner'] = xPlayer.identifier,
			['@plate'] = plate
		}, function(result)
			cb(result[1] ~= nil)
		end)
	end
end)

ESX.RegisterServerCallback('parking:getItemAmount', function(source, cb, item)
	local xPlayer = ESX.GetPlayerFromId(source)
	local quantity = xPlayer.getInventoryItem(item).count
	cb(quantity)
end)

RegisterNetEvent('parking:setup')
AddEventHandler('parking:setup', function()
	TriggerClientEvent('parking:startSetup', source, true)
	MySQL.Async.execute('DROP TABLE `parking`')
	Wait(100)
	MySQL.Async.execute('CREATE TABLE `parking` (`pos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL)')
	Wait(1000)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `vehicle` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL AFTER `pos`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `plate` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL AFTER `vehicle`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `parked` tinyint(1) NOT NULL DEFAULT 0 AFTER `plate`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `locked` tinyint(1) NOT NULL DEFAULT 0 AFTER `parked`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `hotwired` tinyint(1) NOT NULL DEFAULT 0 AFTER `locked`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `lockpicked` tinyint(1) NOT NULL DEFAULT 0 AFTER `hotwired`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `engine` tinyint(1) NOT NULL DEFAULT 0 AFTER `lockpicked`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `gps` tinyint(1) NOT NULL DEFAULT 0 AFTER `engine`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `date` varchar(50) NOT NULL AFTER `gps`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `expiredate` varchar(50) NOT NULL AFTER `date`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `owned_vehicles` DROP `stored`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `owned_vehicles` DROP `state`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `owned_vehicles` ADD `state` BOOLEAN NOT NULL DEFAULT FALSE AFTER `owner`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `owned_vehicles` ADD `stored` BOOLEAN NOT NULL DEFAULT FALSE AFTER `state`')
	Wait(100)
	MySQL.Async.execute('DELETE FROM `items` WHERE `items`.`name` = "wrench"')
	Wait(100)
	MySQL.Async.execute('DELETE FROM `items` WHERE `items`.`name` = "gps_tracker"')
	Wait(100)
	MySQL.Async.execute('INSERT INTO items (name, label, weight, rare, can_remove) VALUES (@name, @label, @weight, @rare, @can_remove)',
		{
			["@name"] = 'wrench', 
			['@label'] = 'Wrench',
			['@weight'] = 1,
			['@rare'] = 0,
			['@can_remove'] = 1,
		}, function (rowschanged)
		if rowschanged == 0 then
			MySQL.Async.execute('INSERT INTO items (name, label, limit, rare, can_remove) VALUES (@name, @label, @limit, @rare, @can_remove)',
				{
					["@name"] = 'wrench', 
					['@label'] = 'Wrench',
					['@limit'] = 10,
					['@rare'] = 0,
					['@can_remove'] = 1,
				}, function (rowschanged)
				if rowschanged == 0 then
					
				end
			end)
		end
	end)
	Wait(100)
	MySQL.Async.execute('INSERT INTO items (name, label, weight, rare, can_remove) VALUES (@name, @label, @weight, @rare, @can_remove)',
		{
			["@name"] = 'gps_tracker', 
			['@label'] = 'gps_tracker',
			['@weight'] = 1,
			['@rare'] = 0,
			['@can_remove'] = 1,
		}, function (rowschanged)
		if rowschanged == 0 then
			MySQL.Async.execute('INSERT INTO items (name, label, limit, rare, can_remove) VALUES (@name, @label, @limit, @rare, @can_remove)',
				{
					["@name"] = 'gps_tracker', 
					['@label'] = 'gps_tracker',
					['@limit'] = 10,
					['@rare'] = 0,
					['@can_remove'] = 1,
				}, function (rowschanged)
				if rowschanged == 0 then
					
				end
			end)
		end
	end)
	Wait(10000)
	TriggerClientEvent('parking:endSetup', source, true)
	SetupComplete = true
end)

RegisterNetEvent('parking:Update')
AddEventHandler('parking:Update', function()
	TriggerClientEvent('parking:startSetup', source, true)
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` DROP `parked`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` DROP `locked`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` DROP `hotwired`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` DROP `engine`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` DROP `gps`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` DROP `date`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` DROP `expiredate`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `parked` tinyint(1) NOT NULL DEFAULT 0 AFTER `plate`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `locked` tinyint(1) NOT NULL DEFAULT 0 AFTER `parked`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `hotwired` tinyint(1) NOT NULL DEFAULT 0 AFTER `locked`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `lockpicked` tinyint(1) NOT NULL DEFAULT 0 AFTER `hotwired`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `engine` tinyint(1) NOT NULL DEFAULT 0 AFTER `lockpicked`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `gps` tinyint(1) NOT NULL DEFAULT 0 AFTER `engine`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `date` varchar(50) NOT NULL AFTER `gps`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `parking` ADD `expiredate` varchar(50) NOT NULL AFTER `date`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `owned_vehicles` DROP `stored`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `owned_vehicles` DROP `state`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `owned_vehicles` ADD `state` BOOLEAN NOT NULL DEFAULT FALSE AFTER `owner`')
	Wait(100)
	MySQL.Async.execute('ALTER TABLE `owned_vehicles` ADD `stored` BOOLEAN NOT NULL DEFAULT FALSE AFTER `state`')
	Wait(100)
	MySQL.Async.execute('DELETE FROM `items` WHERE `items`.`name` = "wrench"')
	Wait(100)
	MySQL.Async.execute('DELETE FROM `items` WHERE `items`.`name` = "gps_tracker"')
	Wait(100)
	MySQL.Async.execute('INSERT INTO items (name, label, weight, rare, can_remove) VALUES (@name, @label, @weight, @rare, @can_remove)',
		{
			["@name"] = 'wrench', 
			['@label'] = 'Wrench',
			['@weight'] = 1,
			['@rare'] = 0,
			['@can_remove'] = 1,
		}, function (rowschanged)
		if rowschanged == 0 then
			MySQL.Async.execute('INSERT INTO items (name, label, limit, rare, can_remove) VALUES (@name, @label, @limit, @rare, @can_remove)',
				{
					["@name"] = 'wrench', 
					['@label'] = 'Wrench',
					['@limit'] = 10,
					['@rare'] = 0,
					['@can_remove'] = 1,
				}, function (rowschanged)
				if rowschanged == 0 then
					
				end
			end)
		end
	end)
	Wait(100)
	MySQL.Async.execute('INSERT INTO items (name, label, weight, rare, can_remove) VALUES (@name, @label, @weight, @rare, @can_remove)',
		{
			["@name"] = 'gps_tracker', 
			['@label'] = 'gps_tracker',
			['@weight'] = 1,
			['@rare'] = 0,
			['@can_remove'] = 1,
		}, function (rowschanged)
		if rowschanged == 0 then
			MySQL.Async.execute('INSERT INTO items (name, label, limit, rare, can_remove) VALUES (@name, @label, @limit, @rare, @can_remove)',
				{
					["@name"] = 'gps_tracker', 
					['@label'] = 'gps_tracker',
					['@limit'] = 10,
					['@rare'] = 0,
					['@can_remove'] = 1,
				}, function (rowschanged)
				if rowschanged == 0 then
					
				end
			end)
		end
	end)
	Wait(10000)
	TriggerClientEvent('parking:endSetup', source, true)
	SetupComplete = true
end)

RegisterNetEvent("parking:ParkVehicle")
AddEventHandler("parking:ParkVehicle", function (plate, vehProps, vehPos, locked, hotwired, parked, engine, gps)
    MySQL.Async.fetchAll('SELECT * FROM parking WHERE plate = @plate', {['@plate'] = plate}, function(vehicle)
	plate = vehProps["plate"]
        if vehicle[1] then
            MySQL.Async.execute('UPDATE parking SET pos=@pos, vehicle=@vehicle, locked=@locked, hotwired=@hotwired, parked=@parked, engine=@engine, gps=@gps WHERE plate=@plate', {
			["@pos"] = json.encode(vehPos), 
			['@vehicle'] = json.encode(vehProps), 
			['@plate'] = plate,
			['@locked'] = locked,
			['@hotwired'] = hotwired,
			['@parked'] = parked,
			['@engine'] = engine,
			['@gps'] = gps
			}, function (rowschanged)
                if rowschanged == 0 then
                end
            end)
			if Config.Garages then
				local state = 1
				local stored = 0
				MySQL.Async.execute('UPDATE owned_vehicles SET state=@state WHERE plate=@plate', {
				['@state'] = state,
				['@plate'] = plate
				}, function (rowschanged)
					if rowschanged == 0 then 
						MySQL.Async.execute('ALTER TABLE `owned_vehicles` ADD `state` BOOLEAN NOT NULL DEFAULT FALSE AFTER `owner`')
					end
				end)
				Wait(300)
				MySQL.Async.execute('UPDATE owned_vehicles SET stored=@stored WHERE plate=@plate', {
				['@stored'] = stored,
				['@plate'] = plate
				}, function (rowschanged)
					if rowschanged == 0 then 
						MySQL.Async.execute('ALTER TABLE `owned_vehicles` ADD `stored` BOOLEAN NOT NULL DEFAULT FALSE AFTER `owner`')
					end
				end)
			end
			if Config.AdvancedGarage then
				local stored = 0
				MySQL.Async.execute('UPDATE owned_vehicles SET stored=@stored WHERE plate=@plate', {
				['@stored'] = stored,
				['@plate'] = plate
				}, function (rowschanged)
					if rowschanged == 0 then 
						MySQL.Async.execute('ALTER TABLE `owned_vehicles` ADD `stored` BOOLEAN NOT NULL DEFAULT FALSE AFTER `owner`')
					end
				end)
			end
        else
			MySQL.Async.execute('INSERT INTO parking (pos, vehicle, plate, locked, hotwired, parked, engine, gps) VALUES (@pos, @vehicle, @plate, @locked, @hotwired, @parked, @engine, @gps)',
				{
					["@pos"] = json.encode(vehPos), 
					['@vehicle'] = json.encode(vehProps), 
					['@plate'] = plate,
					['@locked'] = locked,
					['@hotwired'] = hotwired,
					['@parked'] = parked,
					['@engine'] = engine,
					['@gps'] = gps
				}, function (rowschanged)
                if rowschanged == 0 then
                end
            end)
        end
    end)
end)

Citizen.CreateThread( function ()
    Wait(200)
    while true do 
        local players = GetPlayers()
		if #players == 0 then
			firstplayer = true
			vehiclesRespawned = {}
		end
        Wait (1000)
    end
end)

RegisterNetEvent("parking:StartParking")
AddEventHandler("parking:StartParking", function ()
	local xPlayers = ESX.GetPlayers()
	for i=1, #xPlayers, 1 do
		local test = xPlayers[i]
		if firstplayer then
			firstplayer = false
			TriggerClientEvent("parking:ResetVehicles", test, vehiclesRespawned)
		end
		break
	end
end)

RegisterNetEvent("parking:RemoveVehicleFromDatabase")
AddEventHandler("parking:RemoveVehicleFromDatabase", function (plate)
    MySQL.Async.execute('DELETE FROM parking WHERE plate =@plate', {
		['@plate'] = plate
	}, function (rowschanged)
		if rowschanged == 0 then
		end
	end)
end)

RegisterNetEvent('parking:removeItem')
AddEventHandler('parking:removeItem', function(item)
	local xPlayer = ESX.GetPlayerFromId(source)
	xPlayer.removeInventoryItem(item, 1)
end)

RegisterNetEvent("parking:RemoveVehicleFromTable")
AddEventHandler("parking:RemoveVehicleFromTable", function (plate)
    vehiclesRespawned[plate] = nil
end)

RegisterNetEvent("parking:AddVehicleToTable")
AddEventHandler("parking:AddVehicleToTable", function (veh, plate)
    if not vehiclesRespawned[plate] then 
        vehiclesRespawned[plate] = veh
    end
end)

RegisterNetEvent("parking:GPSTracker")
AddEventHandler("parking:GPSTracker", function (install, plate)
    MySQL.Async.execute('UPDATE parking SET gps=@gps WHERE plate=@plate', {
	['@gps'] = install,
	['@plate'] = plate
	}, function (rowschanged)
		if rowschanged == 0 then
		end
	end)
end)

RegisterNetEvent("parking:Lockpicked")
AddEventHandler("parking:Lockpicked", function (lockpicked, plate)
    MySQL.Async.execute('UPDATE parking SET lockpicked=@lockpicked WHERE plate=@plate', {
	['@lockpicked'] = lockpicked,
	['@plate'] = plate
	}, function (rowschanged)
		if rowschanged == 0 then
		end
	end)
end)

ESX.RegisterServerCallback('parking:IfVehicleExist', function(source, cb)
    cb(vehiclesRespawned)
end)

ESX.RegisterServerCallback('parking:GetAllVehicles', function(source, cb)
    MySQL.Async.fetchAll('SELECT * FROM parking', {}, function(vehicles)
        cb(vehicles)
    end)
end)

function havePermission(xPlayer, exclude)	-- you can exclude rank(s) from having permission to specific commands 	[exclude only take tables]
	if exclude and type(exclude) ~= 'table' then exclude = nil;end	-- will prevent from errors if you pass wrong argument

	local playerGroup = xPlayer.getGroup()
	for k,v in pairs(Config.adminRanks) do
		if v == playerGroup then
			if not exclude then
				return true
			else
				for a,b in pairs(exclude) do
					if b == v then
						return false
					end
				end
				return true
			end
		end
	end
	return false
end

ESX.RegisterServerCallback('parking:InstallJobs', function(source, cb)
	if source ~= 0 then
		local xPlayer = ESX.GetPlayerFromId(source)
		if haveInstallJob(xPlayer) then
			cb(true)
		else
			cb(false)
		end
	end
end)

function haveInstallJob(xPlayer)	-- you can exclude rank(s) from having permission to specific commands 	[exclude only take tables]
	local playerJob = xPlayer.getJob().name
	for k,v in pairs(Config.InstallJobs) do
		if v == playerJob then
			return true
		end
	end
	return false
end

ESX.RegisterServerCallback('parking:UninstallJobs', function(source, cb)
	if source ~= 0 then
		local xPlayer = ESX.GetPlayerFromId(source)
		if haveUninstallJob(xPlayer) then
			cb(true)
		else
			cb(false)
		end
	end
end)

function haveUninstallJob(xPlayer)	-- you can exclude rank(s) from having permission to specific commands 	[exclude only take tables]
	local playerJob = xPlayer.getJob().name
	for k,v in pairs(Config.UninstallJobs) do
		if v == playerJob then
			return true
		end
	end
	return false
end

function haveJob(xPlayer)	-- you can exclude rank(s) from having permission to specific commands 	[exclude only take tables]

	local playerJob = xPlayer.getJob().name
	for k,v in pairs(Config.WhitelistedJobs) do
		if v == playerGroup then
			if not exclude then
				return true
			else
				return true
			end
		end
	end
	return false
end

RegisterCommand("parkingsetup", function(source, args, rawCommand)
	if source ~= 0 then
		local xPlayer = ESX.GetPlayerFromId(source)
		if not SetupComplete then
			if havePermission(xPlayer) then
				TriggerEvent('parking:setup')
			end
		else
			TriggerClientEvent('parking:alreadySetup', source, true)
		end
	end
end, false)

RegisterCommand("searchVehicle", function(source, args, rawCommand)
	if source ~= 0 then
		local xPlayer = ESX.GetPlayerFromId(source)
		plate = args[1]
		if haveJob(xPlayer) then
			if Config.JobGps then
				TriggerClientEvent('parking:searchVehicle', source, plate)
			end
		else
			MySQL.Async.fetchAll("SELECT * FROM `owned_vehicles`", {},
			function(result)
				local foundIdentifier = nil
				for i=1, #result, 1 do
					local vehicleData = json.decode(result[i].vehicle)
					if vehicleData.plate == plate then
						foundIdentifier = result[i].owner
						break
					end
				end
				if xPlayer.identifier == foundIdentifier then
					if Config.PlayerGps then
						TriggerClientEvent('parking:searchVehicle', source, plate)
					end
				end
			end)
		end
	end
end, false)

RegisterCommand("searchEnd", function(source, args, rawCommand)
	if source ~= 0 then
		local xPlayer = ESX.GetPlayerFromId(source)
		plate = args[1]
		if xPlayer.getJob().name.label == 'police' then
			TriggerClientEvent('parking:searchEnd', source, plate)
		else
			MySQL.Async.fetchAll("SELECT * FROM `owned_vehicles`", {},
			function(result)
				local foundIdentifier = nil
				for i=1, #result, 1 do
					local vehicleData = json.decode(result[i].vehicle)
					if vehicleData.plate == plate then
						foundIdentifier = result[i].owner
						break
					end
				end
				if xPlayer.identifier == foundIdentifier then
					TriggerClientEvent('parking:searchEnd', source, plate)
				end
			end)
		end
	end
end, false)

RegisterCommand("parkingupdate", function(source, args, rawCommand)
	if source ~= 0 then
		local xPlayer = ESX.GetPlayerFromId(source)
		if not SetupComplete then
			if havePermission(xPlayer) then
				TriggerEvent('parking:Update')
			end
		else
			TriggerClientEvent('parking:alreadySetup', source, true)
		end
	end
end, false)